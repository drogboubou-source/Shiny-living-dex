(function () {
  function compute(pokemon, collection, regions) {
    const total = pokemon.length;
    const caught = pokemon.filter((p) => collection[p.id].caught).length;
    const perfect = pokemon.filter((p) => collection[p.id].perfect).length;
    const encounters = pokemon.reduce((sum, p) => sum + Number(collection[p.id].encounters || 0), 0);
    const eggs = pokemon.reduce((sum, p) => sum + Number(collection[p.id].eggs || 0), 0);
    const regionStats = regions.map((region) => {
      const list = pokemon.filter((p) => p.region === region.name);
      const regionCaught = list.filter((p) => collection[p.id].caught).length;
      return {
        ...region,
        total: list.length,
        caught: regionCaught,
        perfect: list.filter((p) => collection[p.id].perfect).length,
        percent: list.length ? Math.round((regionCaught / list.length) * 1000) / 10 : 0
      };
    });
    return {
      total,
      caught,
      missing: total - caught,
      perfect,
      encounters,
      eggs,
      percent: total ? Math.round((caught / total) * 1000) / 10 : 0,
      regionStats
    };
  }

  window.DexStats = { compute };
})();
