(function () {
  const KEY = "shiny_living_dex_refonte_v3";

  function normalizeEntry(entry) {
    return {
      caught: Boolean(entry && entry.caught),
      perfect: Boolean(entry && entry.perfect),
      nickname: entry && entry.nickname ? String(entry.nickname) : "",
      eggs: Number(entry && entry.eggs) || 0,
      encounters: Number(entry && entry.encounters) || 0,
      captureDate: entry && entry.captureDate ? String(entry.captureDate) : "",
      videoUrl: entry && entry.videoUrl ? String(entry.videoUrl) : "",
      notes: entry && entry.notes ? String(entry.notes) : "",
      updatedAt: entry && entry.updatedAt ? String(entry.updatedAt) : ""
    };
  }

  function fromLegacyRow(row) {
    const caught = Boolean(row && (row["Date de capture"] || row["Nombre de rencontres"] || row["Surnoms"] || row["Lien YouTube"] || row["Contexte de capture"]));
    const perfectRaw = String(row && row["Parfait"] || "").toLowerCase();
    return normalizeEntry({
      caught,
      perfect: perfectRaw === "true" || perfectRaw === "oui" || perfectRaw === "1",
      nickname: row && row["Surnoms"],
      eggs: row && row["Oeufs parent parfait"],
      encounters: row && row["Nombre de rencontres"],
      captureDate: row && row["Date de capture"],
      videoUrl: row && row["Lien YouTube"],
      notes: row && row["Contexte de capture"]
    });
  }

  function loadCollection(pokemon) {
    const stored = localStorage.getItem(KEY);
    const parsed = stored ? JSON.parse(stored) : {};
    const collection = {};
    pokemon.forEach((p) => {
      collection[p.id] = normalizeEntry(parsed[p.id]);
    });
    return collection;
  }

  function saveCollection(collection) {
    localStorage.setItem(KEY, JSON.stringify(collection));
  }

  function exportCollection(collection, pokemon) {
    return pokemon.map((p) => {
      const entry = normalizeEntry(collection[p.id]);
      return {
        "N° pokédex": p.id,
        "Noms": p.name,
        "Surnoms": entry.nickname,
        "Oeufs parent parfait": entry.eggs || "",
        "Nombre de rencontres": entry.encounters || "",
        "Date de capture": entry.captureDate,
        "Lien YouTube": entry.videoUrl,
        "Contexte de capture": entry.notes,
        "IV parfaits": "",
        "Parfait": entry.perfect ? "Oui" : ""
      };
    });
  }

  function importCollection(raw, pokemon) {
    const parsed = JSON.parse(raw);
    const next = {};
    if (Array.isArray(parsed)) {
      parsed.forEach((row) => {
        const id = Number(row["N° pokédex"] || row.id);
        if (id) next[id] = fromLegacyRow(row);
      });
    } else {
      Object.keys(parsed).forEach((id) => {
        next[id] = normalizeEntry(parsed[id]);
      });
    }
    const collection = {};
    pokemon.forEach((p) => {
      collection[p.id] = normalizeEntry(next[p.id]);
    });
    saveCollection(collection);
    return collection;
  }

  window.DexStorage = {
    loadCollection,
    saveCollection,
    exportCollection,
    importCollection,
    normalizeEntry
  };
})();
