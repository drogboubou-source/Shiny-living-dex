﻿window.POKEMON_BASE = {
    "regions":  [
                    {
                        "color":  "#e05252",
                        "gen":  1,
                        "end":  151,
                        "name":  "Kanto",
                        "start":  1
                    },
                    {
                        "color":  "#e8a020",
                        "gen":  2,
                        "end":  251,
                        "name":  "Johto",
                        "start":  152
                    },
                    {
                        "color":  "#2db87a",
                        "gen":  3,
                        "end":  386,
                        "name":  "Hoenn",
                        "start":  252
                    },
                    {
                        "color":  "#4a9de0",
                        "gen":  4,
                        "end":  493,
                        "name":  "Sinnoh",
                        "start":  387
                    },
                    {
                        "color":  "#9090a0",
                        "gen":  5,
                        "end":  649,
                        "name":  "Unys",
                        "start":  494
                    },
                    {
                        "color":  "#8060e0",
                        "gen":  6,
                        "end":  721,
                        "name":  "Kalos",
                        "start":  650
                    },
                    {
                        "color":  "#e07830",
                        "gen":  7,
                        "end":  809,
                        "name":  "Alola",
                        "start":  722
                    },
                    {
                        "color":  "#c040a0",
                        "gen":  8,
                        "end":  905,
                        "name":  "Galar",
                        "start":  810
                    },
                    {
                        "color":  "#50b840",
                        "gen":  9,
                        "end":  1025,
                        "name":  "Paldea",
                        "start":  906
                    }
                ],
    "pokemon":  [
                    {
                        "id":  1,
                        "name":  "Bulbizarre",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1.png"
                    },
                    {
                        "id":  2,
                        "name":  "Herbizarre",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/2.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/2.png"
                    },
                    {
                        "id":  3,
                        "name":  "Florizarre",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/3.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/3.png"
                    },
                    {
                        "id":  4,
                        "name":  "Salamèche",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/4.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/4.png"
                    },
                    {
                        "id":  5,
                        "name":  "Reptincel",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/5.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/5.png"
                    },
                    {
                        "id":  6,
                        "name":  "Dracaufeu",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/6.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/6.png"
                    },
                    {
                        "id":  7,
                        "name":  "Carapuce",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/7.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/7.png"
                    },
                    {
                        "id":  8,
                        "name":  "Carabaffe",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/8.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/8.png"
                    },
                    {
                        "id":  9,
                        "name":  "Tortank",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/9.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/9.png"
                    },
                    {
                        "id":  10,
                        "name":  "Chenipan",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/10.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/10.png"
                    },
                    {
                        "id":  11,
                        "name":  "Chrysacier",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/11.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/11.png"
                    },
                    {
                        "id":  12,
                        "name":  "Papilusion",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/12.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/12.png"
                    },
                    {
                        "id":  13,
                        "name":  "Aspicot",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/13.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/13.png"
                    },
                    {
                        "id":  14,
                        "name":  "Coconfort",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/14.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/14.png"
                    },
                    {
                        "id":  15,
                        "name":  "Dardargnan",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/15.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/15.png"
                    },
                    {
                        "id":  16,
                        "name":  "Roucool",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/16.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/16.png"
                    },
                    {
                        "id":  17,
                        "name":  "Roucoups",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/17.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/17.png"
                    },
                    {
                        "id":  18,
                        "name":  "Roucarnage",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/18.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/18.png"
                    },
                    {
                        "id":  19,
                        "name":  "Rattata",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/19.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/19.png"
                    },
                    {
                        "id":  20,
                        "name":  "Rattatac",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/20.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/20.png"
                    },
                    {
                        "id":  21,
                        "name":  "Piafabec",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/21.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/21.png"
                    },
                    {
                        "id":  22,
                        "name":  "Rapasdepic",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/22.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/22.png"
                    },
                    {
                        "id":  23,
                        "name":  "Abo",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/23.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/23.png"
                    },
                    {
                        "id":  24,
                        "name":  "Arbok",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/24.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/24.png"
                    },
                    {
                        "id":  25,
                        "name":  "Pikachu",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/25.png"
                    },
                    {
                        "id":  26,
                        "name":  "Raichu",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/26.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/26.png"
                    },
                    {
                        "id":  27,
                        "name":  "Sabelette",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/27.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/27.png"
                    },
                    {
                        "id":  28,
                        "name":  "Sablaireau",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/28.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/28.png"
                    },
                    {
                        "id":  29,
                        "name":  "Nidoran♀",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/29.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/29.png"
                    },
                    {
                        "id":  30,
                        "name":  "Nidorina",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/30.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/30.png"
                    },
                    {
                        "id":  31,
                        "name":  "Nidoqueen",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/31.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/31.png"
                    },
                    {
                        "id":  32,
                        "name":  "Nidoran♂",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/32.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/32.png"
                    },
                    {
                        "id":  33,
                        "name":  "Nidorino",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/33.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/33.png"
                    },
                    {
                        "id":  34,
                        "name":  "Nidoking",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/34.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/34.png"
                    },
                    {
                        "id":  35,
                        "name":  "Mélofée",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/35.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/35.png"
                    },
                    {
                        "id":  36,
                        "name":  "Mélodelfe",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/36.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/36.png"
                    },
                    {
                        "id":  37,
                        "name":  "Goupix",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/37.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/37.png"
                    },
                    {
                        "id":  38,
                        "name":  "Feunard",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/38.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/38.png"
                    },
                    {
                        "id":  39,
                        "name":  "Rondoudou",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/39.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/39.png"
                    },
                    {
                        "id":  40,
                        "name":  "Grodoudou",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/40.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/40.png"
                    },
                    {
                        "id":  41,
                        "name":  "Nosferapti",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/41.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/41.png"
                    },
                    {
                        "id":  42,
                        "name":  "Nosferalto",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/42.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/42.png"
                    },
                    {
                        "id":  43,
                        "name":  "Mystherbe",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/43.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/43.png"
                    },
                    {
                        "id":  44,
                        "name":  "Ortide",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/44.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/44.png"
                    },
                    {
                        "id":  45,
                        "name":  "Rafflesia",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/45.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/45.png"
                    },
                    {
                        "id":  46,
                        "name":  "Paras",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/46.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/46.png"
                    },
                    {
                        "id":  47,
                        "name":  "Parasect",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/47.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/47.png"
                    },
                    {
                        "id":  48,
                        "name":  "Mimitoss",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/48.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/48.png"
                    },
                    {
                        "id":  49,
                        "name":  "Aéromite",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/49.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/49.png"
                    },
                    {
                        "id":  50,
                        "name":  "Taupiqueur",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/50.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/50.png"
                    },
                    {
                        "id":  51,
                        "name":  "Triopikeur",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/51.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/51.png"
                    },
                    {
                        "id":  52,
                        "name":  "Miaouss",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/52.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/52.png"
                    },
                    {
                        "id":  53,
                        "name":  "Persian",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/53.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/53.png"
                    },
                    {
                        "id":  54,
                        "name":  "Psykokwak",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/54.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/54.png"
                    },
                    {
                        "id":  55,
                        "name":  "Akwakwak",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/55.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/55.png"
                    },
                    {
                        "id":  56,
                        "name":  "Férosinge",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/56.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/56.png"
                    },
                    {
                        "id":  57,
                        "name":  "Colossinge",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/57.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/57.png"
                    },
                    {
                        "id":  58,
                        "name":  "Caninos",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/58.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/58.png"
                    },
                    {
                        "id":  59,
                        "name":  "Arcanin",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/59.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/59.png"
                    },
                    {
                        "id":  60,
                        "name":  "Ptitard",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/60.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/60.png"
                    },
                    {
                        "id":  61,
                        "name":  "Têtarte",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/61.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/61.png"
                    },
                    {
                        "id":  62,
                        "name":  "Tartard",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/62.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/62.png"
                    },
                    {
                        "id":  63,
                        "name":  "Abra",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/63.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/63.png"
                    },
                    {
                        "id":  64,
                        "name":  "Kadabra",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/64.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/64.png"
                    },
                    {
                        "id":  65,
                        "name":  "Alakazam",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/65.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/65.png"
                    },
                    {
                        "id":  66,
                        "name":  "Machoc",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/66.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/66.png"
                    },
                    {
                        "id":  67,
                        "name":  "Machopeur",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/67.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/67.png"
                    },
                    {
                        "id":  68,
                        "name":  "Mackogneur",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/68.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/68.png"
                    },
                    {
                        "id":  69,
                        "name":  "Chétiflor",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/69.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/69.png"
                    },
                    {
                        "id":  70,
                        "name":  "Boustiflor",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/70.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/70.png"
                    },
                    {
                        "id":  71,
                        "name":  "Empiflor",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/71.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/71.png"
                    },
                    {
                        "id":  72,
                        "name":  "Tentacool",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/72.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/72.png"
                    },
                    {
                        "id":  73,
                        "name":  "Tentacruel",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/73.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/73.png"
                    },
                    {
                        "id":  74,
                        "name":  "Racaillou",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/74.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/74.png"
                    },
                    {
                        "id":  75,
                        "name":  "Gravalanch",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/75.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/75.png"
                    },
                    {
                        "id":  76,
                        "name":  "Grolem",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/76.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/76.png"
                    },
                    {
                        "id":  77,
                        "name":  "Ponyta",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/77.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/77.png"
                    },
                    {
                        "id":  78,
                        "name":  "Galopa",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/78.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/78.png"
                    },
                    {
                        "id":  79,
                        "name":  "Ramoloss",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/79.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/79.png"
                    },
                    {
                        "id":  80,
                        "name":  "Flagadoss",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/80.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/80.png"
                    },
                    {
                        "id":  81,
                        "name":  "Magnéti",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/81.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/81.png"
                    },
                    {
                        "id":  82,
                        "name":  "Magnéton",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/82.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/82.png"
                    },
                    {
                        "id":  83,
                        "name":  "Canarticho",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/83.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/83.png"
                    },
                    {
                        "id":  84,
                        "name":  "Doduo",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/84.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/84.png"
                    },
                    {
                        "id":  85,
                        "name":  "Dodrio",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/85.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/85.png"
                    },
                    {
                        "id":  86,
                        "name":  "Otaria",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/86.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/86.png"
                    },
                    {
                        "id":  87,
                        "name":  "Lamantine",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/87.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/87.png"
                    },
                    {
                        "id":  88,
                        "name":  "Tadmorv",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/88.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/88.png"
                    },
                    {
                        "id":  89,
                        "name":  "Grotadmorv",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/89.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/89.png"
                    },
                    {
                        "id":  90,
                        "name":  "Kokiyas",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/90.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/90.png"
                    },
                    {
                        "id":  91,
                        "name":  "Crustabri",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/91.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/91.png"
                    },
                    {
                        "id":  92,
                        "name":  "Fantominus",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/92.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/92.png"
                    },
                    {
                        "id":  93,
                        "name":  "Spectrum",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/93.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/93.png"
                    },
                    {
                        "id":  94,
                        "name":  "Ectoplasma",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/94.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/94.png"
                    },
                    {
                        "id":  95,
                        "name":  "Onix",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/95.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/95.png"
                    },
                    {
                        "id":  96,
                        "name":  "Soporifik",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/96.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/96.png"
                    },
                    {
                        "id":  97,
                        "name":  "Hypnomade",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/97.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/97.png"
                    },
                    {
                        "id":  98,
                        "name":  "Krabby",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/98.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/98.png"
                    },
                    {
                        "id":  99,
                        "name":  "Krabboss",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/99.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/99.png"
                    },
                    {
                        "id":  100,
                        "name":  "Voltorbe",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/100.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/100.png"
                    },
                    {
                        "id":  101,
                        "name":  "Électrode",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/101.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/101.png"
                    },
                    {
                        "id":  102,
                        "name":  "Noeunoeuf",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/102.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/102.png"
                    },
                    {
                        "id":  103,
                        "name":  "Noadkoko",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/103.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/103.png"
                    },
                    {
                        "id":  104,
                        "name":  "Osselait",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/104.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/104.png"
                    },
                    {
                        "id":  105,
                        "name":  "Ossatueur",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/105.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/105.png"
                    },
                    {
                        "id":  106,
                        "name":  "Kicklee",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/106.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/106.png"
                    },
                    {
                        "id":  107,
                        "name":  "Tygnon",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/107.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/107.png"
                    },
                    {
                        "id":  108,
                        "name":  "Excelangue",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/108.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/108.png"
                    },
                    {
                        "id":  109,
                        "name":  "Smogo",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/109.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/109.png"
                    },
                    {
                        "id":  110,
                        "name":  "Smogogo",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/110.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/110.png"
                    },
                    {
                        "id":  111,
                        "name":  "Rhinocorne",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/111.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/111.png"
                    },
                    {
                        "id":  112,
                        "name":  "Rhinoféros",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/112.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/112.png"
                    },
                    {
                        "id":  113,
                        "name":  "Leveinard",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/113.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/113.png"
                    },
                    {
                        "id":  114,
                        "name":  "Saquedeneu",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/114.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/114.png"
                    },
                    {
                        "id":  115,
                        "name":  "Kangourex",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/115.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/115.png"
                    },
                    {
                        "id":  116,
                        "name":  "Hypotrempe",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/116.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/116.png"
                    },
                    {
                        "id":  117,
                        "name":  "Hypocéan",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/117.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/117.png"
                    },
                    {
                        "id":  118,
                        "name":  "Poissirène",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/118.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/118.png"
                    },
                    {
                        "id":  119,
                        "name":  "Poissoroy",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/119.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/119.png"
                    },
                    {
                        "id":  120,
                        "name":  "Stari",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/120.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/120.png"
                    },
                    {
                        "id":  121,
                        "name":  "Staross",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/121.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/121.png"
                    },
                    {
                        "id":  122,
                        "name":  "M. Mime",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/122.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/122.png"
                    },
                    {
                        "id":  123,
                        "name":  "Insécateur",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/123.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/123.png"
                    },
                    {
                        "id":  124,
                        "name":  "Lippoutou",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/124.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/124.png"
                    },
                    {
                        "id":  125,
                        "name":  "Élektek",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/125.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/125.png"
                    },
                    {
                        "id":  126,
                        "name":  "Magmar",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/126.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/126.png"
                    },
                    {
                        "id":  127,
                        "name":  "Scarabrute",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/127.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/127.png"
                    },
                    {
                        "id":  128,
                        "name":  "Tauros",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/128.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/128.png"
                    },
                    {
                        "id":  129,
                        "name":  "Magicarpe",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/129.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/129.png"
                    },
                    {
                        "id":  130,
                        "name":  "Léviator",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/130.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/130.png"
                    },
                    {
                        "id":  131,
                        "name":  "Lokhlass",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/131.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/131.png"
                    },
                    {
                        "id":  132,
                        "name":  "Métamorph",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/132.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/132.png"
                    },
                    {
                        "id":  133,
                        "name":  "Évoli",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/133.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/133.png"
                    },
                    {
                        "id":  134,
                        "name":  "Aquali",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/134.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/134.png"
                    },
                    {
                        "id":  135,
                        "name":  "Voltali",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/135.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/135.png"
                    },
                    {
                        "id":  136,
                        "name":  "Pyroli",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/136.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/136.png"
                    },
                    {
                        "id":  137,
                        "name":  "Porygon",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/137.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/137.png"
                    },
                    {
                        "id":  138,
                        "name":  "Amonita",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/138.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/138.png"
                    },
                    {
                        "id":  139,
                        "name":  "Amonistar",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/139.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/139.png"
                    },
                    {
                        "id":  140,
                        "name":  "Kabuto",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/140.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/140.png"
                    },
                    {
                        "id":  141,
                        "name":  "Kabutops",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/141.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/141.png"
                    },
                    {
                        "id":  142,
                        "name":  "Ptéra",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/142.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/142.png"
                    },
                    {
                        "id":  143,
                        "name":  "Ronflex",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/143.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/143.png"
                    },
                    {
                        "id":  144,
                        "name":  "Artikodin",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/144.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/144.png"
                    },
                    {
                        "id":  145,
                        "name":  "Électhor",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/145.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/145.png"
                    },
                    {
                        "id":  146,
                        "name":  "Sulfura",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/146.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/146.png"
                    },
                    {
                        "id":  147,
                        "name":  "Minidraco",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/147.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/147.png"
                    },
                    {
                        "id":  148,
                        "name":  "Draco",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/148.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/148.png"
                    },
                    {
                        "id":  149,
                        "name":  "Dracolosse",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/149.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/149.png"
                    },
                    {
                        "id":  150,
                        "name":  "Mewtwo",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/150.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/150.png"
                    },
                    {
                        "id":  151,
                        "name":  "Mew",
                        "region":  "Kanto",
                        "generation":  1,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/151.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/151.png"
                    },
                    {
                        "id":  152,
                        "name":  "Germignon",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/152.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/152.png"
                    },
                    {
                        "id":  153,
                        "name":  "Macronium",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/153.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/153.png"
                    },
                    {
                        "id":  154,
                        "name":  "Méganium",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/154.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/154.png"
                    },
                    {
                        "id":  155,
                        "name":  "Héricendre",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/155.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/155.png"
                    },
                    {
                        "id":  156,
                        "name":  "Feurisson",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/156.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/156.png"
                    },
                    {
                        "id":  157,
                        "name":  "Typhlosion",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/157.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/157.png"
                    },
                    {
                        "id":  158,
                        "name":  "Kaiminus",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/158.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/158.png"
                    },
                    {
                        "id":  159,
                        "name":  "Crocrodil",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/159.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/159.png"
                    },
                    {
                        "id":  160,
                        "name":  "Aligatueur",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/160.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/160.png"
                    },
                    {
                        "id":  161,
                        "name":  "Fouinette",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/161.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/161.png"
                    },
                    {
                        "id":  162,
                        "name":  "Fouinar",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/162.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/162.png"
                    },
                    {
                        "id":  163,
                        "name":  "Hoothoot",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/163.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/163.png"
                    },
                    {
                        "id":  164,
                        "name":  "Noarfang",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/164.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/164.png"
                    },
                    {
                        "id":  165,
                        "name":  "Coxy",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/165.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/165.png"
                    },
                    {
                        "id":  166,
                        "name":  "Coxyclaque",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/166.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/166.png"
                    },
                    {
                        "id":  167,
                        "name":  "Mimigal",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/167.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/167.png"
                    },
                    {
                        "id":  168,
                        "name":  "Migalos",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/168.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/168.png"
                    },
                    {
                        "id":  169,
                        "name":  "Nostenfer",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/169.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/169.png"
                    },
                    {
                        "id":  170,
                        "name":  "Loupio",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/170.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/170.png"
                    },
                    {
                        "id":  171,
                        "name":  "Lanturn",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/171.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/171.png"
                    },
                    {
                        "id":  172,
                        "name":  "Pichu",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/172.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/172.png"
                    },
                    {
                        "id":  173,
                        "name":  "Mélo",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/173.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/173.png"
                    },
                    {
                        "id":  174,
                        "name":  "Toudoudou",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/174.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/174.png"
                    },
                    {
                        "id":  175,
                        "name":  "Togepi",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/175.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/175.png"
                    },
                    {
                        "id":  176,
                        "name":  "Togetic",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/176.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/176.png"
                    },
                    {
                        "id":  177,
                        "name":  "Natu",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/177.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/177.png"
                    },
                    {
                        "id":  178,
                        "name":  "Xatu",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/178.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/178.png"
                    },
                    {
                        "id":  179,
                        "name":  "Wattouat",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/179.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/179.png"
                    },
                    {
                        "id":  180,
                        "name":  "Lainergie",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/180.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/180.png"
                    },
                    {
                        "id":  181,
                        "name":  "Pharamp",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/181.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/181.png"
                    },
                    {
                        "id":  182,
                        "name":  "Joliflor",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/182.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/182.png"
                    },
                    {
                        "id":  183,
                        "name":  "Marill",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/183.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/183.png"
                    },
                    {
                        "id":  184,
                        "name":  "Azumarill",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/184.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/184.png"
                    },
                    {
                        "id":  185,
                        "name":  "Simularbre",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/185.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/185.png"
                    },
                    {
                        "id":  186,
                        "name":  "Tarpaud",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/186.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/186.png"
                    },
                    {
                        "id":  187,
                        "name":  "Granivol",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/187.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/187.png"
                    },
                    {
                        "id":  188,
                        "name":  "Floravol",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/188.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/188.png"
                    },
                    {
                        "id":  189,
                        "name":  "Cotovol",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/189.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/189.png"
                    },
                    {
                        "id":  190,
                        "name":  "Capumain",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/190.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/190.png"
                    },
                    {
                        "id":  191,
                        "name":  "Tournegrin",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/191.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/191.png"
                    },
                    {
                        "id":  192,
                        "name":  "Héliatronc",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/192.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/192.png"
                    },
                    {
                        "id":  193,
                        "name":  "Yanma",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/193.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/193.png"
                    },
                    {
                        "id":  194,
                        "name":  "Axoloto",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/194.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/194.png"
                    },
                    {
                        "id":  195,
                        "name":  "Maraiste",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/195.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/195.png"
                    },
                    {
                        "id":  196,
                        "name":  "Mentali",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/196.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/196.png"
                    },
                    {
                        "id":  197,
                        "name":  "Noctali",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/197.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/197.png"
                    },
                    {
                        "id":  198,
                        "name":  "Cornèbre",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/198.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/198.png"
                    },
                    {
                        "id":  199,
                        "name":  "Roigada",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/199.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/199.png"
                    },
                    {
                        "id":  200,
                        "name":  "Feuforêve",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/200.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/200.png"
                    },
                    {
                        "id":  201,
                        "name":  "Zarbi",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/201.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/201.png"
                    },
                    {
                        "id":  202,
                        "name":  "Qulbutoké",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/202.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/202.png"
                    },
                    {
                        "id":  203,
                        "name":  "Girafarig",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/203.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/203.png"
                    },
                    {
                        "id":  204,
                        "name":  "Pomdepik",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/204.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/204.png"
                    },
                    {
                        "id":  205,
                        "name":  "Foretress",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/205.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/205.png"
                    },
                    {
                        "id":  206,
                        "name":  "Insolourdo",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/206.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/206.png"
                    },
                    {
                        "id":  207,
                        "name":  "Scorplane",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/207.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/207.png"
                    },
                    {
                        "id":  208,
                        "name":  "Steelix",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/208.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/208.png"
                    },
                    {
                        "id":  209,
                        "name":  "Snubbull",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/209.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/209.png"
                    },
                    {
                        "id":  210,
                        "name":  "Granbull",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/210.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/210.png"
                    },
                    {
                        "id":  211,
                        "name":  "Qwilfish",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/211.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/211.png"
                    },
                    {
                        "id":  212,
                        "name":  "Cizayox",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/212.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/212.png"
                    },
                    {
                        "id":  213,
                        "name":  "Caratroc",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/213.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/213.png"
                    },
                    {
                        "id":  214,
                        "name":  "Scarhino",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/214.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/214.png"
                    },
                    {
                        "id":  215,
                        "name":  "Farfuret",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/215.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/215.png"
                    },
                    {
                        "id":  216,
                        "name":  "Teddiursa",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/216.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/216.png"
                    },
                    {
                        "id":  217,
                        "name":  "Ursaring",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/217.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/217.png"
                    },
                    {
                        "id":  218,
                        "name":  "Limagma",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/218.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/218.png"
                    },
                    {
                        "id":  219,
                        "name":  "Volcaropod",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/219.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/219.png"
                    },
                    {
                        "id":  220,
                        "name":  "Marcacrin",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/220.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/220.png"
                    },
                    {
                        "id":  221,
                        "name":  "Cochignon",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/221.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/221.png"
                    },
                    {
                        "id":  222,
                        "name":  "Corayon",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/222.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/222.png"
                    },
                    {
                        "id":  223,
                        "name":  "Rémoraid",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/223.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/223.png"
                    },
                    {
                        "id":  224,
                        "name":  "Octillery",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/224.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/224.png"
                    },
                    {
                        "id":  225,
                        "name":  "Cadoizo",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/225.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/225.png"
                    },
                    {
                        "id":  226,
                        "name":  "Démanta",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/226.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/226.png"
                    },
                    {
                        "id":  227,
                        "name":  "Airmure",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/227.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/227.png"
                    },
                    {
                        "id":  228,
                        "name":  "Malosse",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/228.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/228.png"
                    },
                    {
                        "id":  229,
                        "name":  "Démolosse",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/229.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/229.png"
                    },
                    {
                        "id":  230,
                        "name":  "Hyporoi",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/230.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/230.png"
                    },
                    {
                        "id":  231,
                        "name":  "Phanpy",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/231.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/231.png"
                    },
                    {
                        "id":  232,
                        "name":  "Donphan",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/232.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/232.png"
                    },
                    {
                        "id":  233,
                        "name":  "Porygon2",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/233.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/233.png"
                    },
                    {
                        "id":  234,
                        "name":  "Cerfrousse",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/234.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/234.png"
                    },
                    {
                        "id":  235,
                        "name":  "Queulorior",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/235.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/235.png"
                    },
                    {
                        "id":  236,
                        "name":  "Debugant",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/236.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/236.png"
                    },
                    {
                        "id":  237,
                        "name":  "Kapoera",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/237.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/237.png"
                    },
                    {
                        "id":  238,
                        "name":  "Lippouti",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/238.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/238.png"
                    },
                    {
                        "id":  239,
                        "name":  "Élekid",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/239.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/239.png"
                    },
                    {
                        "id":  240,
                        "name":  "Magby",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/240.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/240.png"
                    },
                    {
                        "id":  241,
                        "name":  "Écrémeuh",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/241.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/241.png"
                    },
                    {
                        "id":  242,
                        "name":  "Leuphorie",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/242.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/242.png"
                    },
                    {
                        "id":  243,
                        "name":  "Raikou",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/243.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/243.png"
                    },
                    {
                        "id":  244,
                        "name":  "Entei",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/244.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/244.png"
                    },
                    {
                        "id":  245,
                        "name":  "Suicune",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/245.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/245.png"
                    },
                    {
                        "id":  246,
                        "name":  "Embrylex",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/246.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/246.png"
                    },
                    {
                        "id":  247,
                        "name":  "Ymphect",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/247.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/247.png"
                    },
                    {
                        "id":  248,
                        "name":  "Tyranocif",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/248.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/248.png"
                    },
                    {
                        "id":  249,
                        "name":  "Lugia",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/249.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/249.png"
                    },
                    {
                        "id":  250,
                        "name":  "Ho-Oh",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/250.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/250.png"
                    },
                    {
                        "id":  251,
                        "name":  "Celebi",
                        "region":  "Johto",
                        "generation":  2,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/251.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/251.png"
                    },
                    {
                        "id":  252,
                        "name":  "Arcko",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/252.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/252.png"
                    },
                    {
                        "id":  253,
                        "name":  "Massko",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/253.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/253.png"
                    },
                    {
                        "id":  254,
                        "name":  "Jungko",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/254.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/254.png"
                    },
                    {
                        "id":  255,
                        "name":  "Poussifeu",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/255.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/255.png"
                    },
                    {
                        "id":  256,
                        "name":  "Galifeu",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/256.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/256.png"
                    },
                    {
                        "id":  257,
                        "name":  "Braségali",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/257.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/257.png"
                    },
                    {
                        "id":  258,
                        "name":  "Gobou",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/258.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/258.png"
                    },
                    {
                        "id":  259,
                        "name":  "Flobio",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/259.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/259.png"
                    },
                    {
                        "id":  260,
                        "name":  "Laggron",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/260.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/260.png"
                    },
                    {
                        "id":  261,
                        "name":  "Medhyèna",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/261.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/261.png"
                    },
                    {
                        "id":  262,
                        "name":  "Grahyèna",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/262.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/262.png"
                    },
                    {
                        "id":  263,
                        "name":  "Zigzaton",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/263.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/263.png"
                    },
                    {
                        "id":  264,
                        "name":  "Linéon",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/264.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/264.png"
                    },
                    {
                        "id":  265,
                        "name":  "Chenipotte",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/265.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/265.png"
                    },
                    {
                        "id":  266,
                        "name":  "Armulys",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/266.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/266.png"
                    },
                    {
                        "id":  267,
                        "name":  "Charmillon",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/267.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/267.png"
                    },
                    {
                        "id":  268,
                        "name":  "Blindalys",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/268.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/268.png"
                    },
                    {
                        "id":  269,
                        "name":  "Papinox",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/269.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/269.png"
                    },
                    {
                        "id":  270,
                        "name":  "Nénupiot",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/270.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/270.png"
                    },
                    {
                        "id":  271,
                        "name":  "Lombre",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/271.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/271.png"
                    },
                    {
                        "id":  272,
                        "name":  "Ludicolo",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/272.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/272.png"
                    },
                    {
                        "id":  273,
                        "name":  "Grainipiot",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/273.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/273.png"
                    },
                    {
                        "id":  274,
                        "name":  "Pifeuil",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/274.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/274.png"
                    },
                    {
                        "id":  275,
                        "name":  "Tengalice",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/275.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/275.png"
                    },
                    {
                        "id":  276,
                        "name":  "Nirondelle",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/276.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/276.png"
                    },
                    {
                        "id":  277,
                        "name":  "Hélédelle",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/277.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/277.png"
                    },
                    {
                        "id":  278,
                        "name":  "Goélise",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/278.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/278.png"
                    },
                    {
                        "id":  279,
                        "name":  "Bekipan",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/279.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/279.png"
                    },
                    {
                        "id":  280,
                        "name":  "Tarsal",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/280.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/280.png"
                    },
                    {
                        "id":  281,
                        "name":  "Kirlia",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/281.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/281.png"
                    },
                    {
                        "id":  282,
                        "name":  "Gardevoir",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/282.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/282.png"
                    },
                    {
                        "id":  283,
                        "name":  "Arakdo",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/283.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/283.png"
                    },
                    {
                        "id":  284,
                        "name":  "Maskadra",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/284.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/284.png"
                    },
                    {
                        "id":  285,
                        "name":  "Balignon",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/285.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/285.png"
                    },
                    {
                        "id":  286,
                        "name":  "Chapignon",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/286.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/286.png"
                    },
                    {
                        "id":  287,
                        "name":  "Parecool",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/287.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/287.png"
                    },
                    {
                        "id":  288,
                        "name":  "Vigoroth",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/288.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/288.png"
                    },
                    {
                        "id":  289,
                        "name":  "Monaflèmit",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/289.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/289.png"
                    },
                    {
                        "id":  290,
                        "name":  "Ningale",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/290.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/290.png"
                    },
                    {
                        "id":  291,
                        "name":  "Ninjask",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/291.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/291.png"
                    },
                    {
                        "id":  292,
                        "name":  "Munja",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/292.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/292.png"
                    },
                    {
                        "id":  293,
                        "name":  "Chuchmur",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/293.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/293.png"
                    },
                    {
                        "id":  294,
                        "name":  "Ramboum",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/294.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/294.png"
                    },
                    {
                        "id":  295,
                        "name":  "Brouhabam",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/295.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/295.png"
                    },
                    {
                        "id":  296,
                        "name":  "Makuhita",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/296.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/296.png"
                    },
                    {
                        "id":  297,
                        "name":  "Hariyama",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/297.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/297.png"
                    },
                    {
                        "id":  298,
                        "name":  "Azurill",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/298.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/298.png"
                    },
                    {
                        "id":  299,
                        "name":  "Tarinor",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/299.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/299.png"
                    },
                    {
                        "id":  300,
                        "name":  "Skitty",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/300.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/300.png"
                    },
                    {
                        "id":  301,
                        "name":  "Delcatty",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/301.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/301.png"
                    },
                    {
                        "id":  302,
                        "name":  "Ténéfix",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/302.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/302.png"
                    },
                    {
                        "id":  303,
                        "name":  "Mysdibule",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/303.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/303.png"
                    },
                    {
                        "id":  304,
                        "name":  "Galekid",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/304.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/304.png"
                    },
                    {
                        "id":  305,
                        "name":  "Galegon",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/305.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/305.png"
                    },
                    {
                        "id":  306,
                        "name":  "Galeking",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/306.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/306.png"
                    },
                    {
                        "id":  307,
                        "name":  "Méditikka",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/307.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/307.png"
                    },
                    {
                        "id":  308,
                        "name":  "Charmina",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/308.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/308.png"
                    },
                    {
                        "id":  309,
                        "name":  "Dynavolt",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/309.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/309.png"
                    },
                    {
                        "id":  310,
                        "name":  "Élecsprint",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/310.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/310.png"
                    },
                    {
                        "id":  311,
                        "name":  "Posipi",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/311.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/311.png"
                    },
                    {
                        "id":  312,
                        "name":  "Négapi",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/312.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/312.png"
                    },
                    {
                        "id":  313,
                        "name":  "Muciole",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/313.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/313.png"
                    },
                    {
                        "id":  314,
                        "name":  "Lumivole",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/314.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/314.png"
                    },
                    {
                        "id":  315,
                        "name":  "Rosélia",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/315.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/315.png"
                    },
                    {
                        "id":  316,
                        "name":  "Gloupti",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/316.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/316.png"
                    },
                    {
                        "id":  317,
                        "name":  "Avaltout",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/317.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/317.png"
                    },
                    {
                        "id":  318,
                        "name":  "Carvanha",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/318.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/318.png"
                    },
                    {
                        "id":  319,
                        "name":  "Sharpedo",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/319.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/319.png"
                    },
                    {
                        "id":  320,
                        "name":  "Wailmer",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/320.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/320.png"
                    },
                    {
                        "id":  321,
                        "name":  "Wailord",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/321.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/321.png"
                    },
                    {
                        "id":  322,
                        "name":  "Chamallot",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/322.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/322.png"
                    },
                    {
                        "id":  323,
                        "name":  "Camérupt",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/323.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/323.png"
                    },
                    {
                        "id":  324,
                        "name":  "Chartor",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/324.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/324.png"
                    },
                    {
                        "id":  325,
                        "name":  "Spoink",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/325.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/325.png"
                    },
                    {
                        "id":  326,
                        "name":  "Groret",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/326.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/326.png"
                    },
                    {
                        "id":  327,
                        "name":  "Spinda",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/327.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/327.png"
                    },
                    {
                        "id":  328,
                        "name":  "Kraknoix",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/328.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/328.png"
                    },
                    {
                        "id":  329,
                        "name":  "Vibraninf",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/329.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/329.png"
                    },
                    {
                        "id":  330,
                        "name":  "Libégon",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/330.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/330.png"
                    },
                    {
                        "id":  331,
                        "name":  "Cacnea",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/331.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/331.png"
                    },
                    {
                        "id":  332,
                        "name":  "Cacturne",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/332.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/332.png"
                    },
                    {
                        "id":  333,
                        "name":  "Tylton",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/333.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/333.png"
                    },
                    {
                        "id":  334,
                        "name":  "Altaria",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/334.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/334.png"
                    },
                    {
                        "id":  335,
                        "name":  "Mangriff",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/335.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/335.png"
                    },
                    {
                        "id":  336,
                        "name":  "Séviper",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/336.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/336.png"
                    },
                    {
                        "id":  337,
                        "name":  "Séléroc",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/337.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/337.png"
                    },
                    {
                        "id":  338,
                        "name":  "Solaroc",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/338.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/338.png"
                    },
                    {
                        "id":  339,
                        "name":  "Barloche",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/339.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/339.png"
                    },
                    {
                        "id":  340,
                        "name":  "Barbicha",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/340.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/340.png"
                    },
                    {
                        "id":  341,
                        "name":  "Écrapince",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/341.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/341.png"
                    },
                    {
                        "id":  342,
                        "name":  "Colhomard",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/342.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/342.png"
                    },
                    {
                        "id":  343,
                        "name":  "Balbuto",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/343.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/343.png"
                    },
                    {
                        "id":  344,
                        "name":  "Kaorine",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/344.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/344.png"
                    },
                    {
                        "id":  345,
                        "name":  "Lilia",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/345.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/345.png"
                    },
                    {
                        "id":  346,
                        "name":  "Vacilys",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/346.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/346.png"
                    },
                    {
                        "id":  347,
                        "name":  "Anorith",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/347.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/347.png"
                    },
                    {
                        "id":  348,
                        "name":  "Armaldo",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/348.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/348.png"
                    },
                    {
                        "id":  349,
                        "name":  "Barpau",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/349.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/349.png"
                    },
                    {
                        "id":  350,
                        "name":  "Milobellus",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/350.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/350.png"
                    },
                    {
                        "id":  351,
                        "name":  "Morphéo",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/351.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/351.png"
                    },
                    {
                        "id":  352,
                        "name":  "Kecleon",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/352.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/352.png"
                    },
                    {
                        "id":  353,
                        "name":  "Polichombr",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/353.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/353.png"
                    },
                    {
                        "id":  354,
                        "name":  "Branette",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/354.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/354.png"
                    },
                    {
                        "id":  355,
                        "name":  "Skelénox",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/355.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/355.png"
                    },
                    {
                        "id":  356,
                        "name":  "Téraclope",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/356.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/356.png"
                    },
                    {
                        "id":  357,
                        "name":  "Tropius",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/357.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/357.png"
                    },
                    {
                        "id":  358,
                        "name":  "Éoko",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/358.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/358.png"
                    },
                    {
                        "id":  359,
                        "name":  "Absol",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/359.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/359.png"
                    },
                    {
                        "id":  360,
                        "name":  "Okéoké",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/360.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/360.png"
                    },
                    {
                        "id":  361,
                        "name":  "Stalgamin",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/361.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/361.png"
                    },
                    {
                        "id":  362,
                        "name":  "Oniglali",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/362.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/362.png"
                    },
                    {
                        "id":  363,
                        "name":  "Obalie",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/363.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/363.png"
                    },
                    {
                        "id":  364,
                        "name":  "Phogleur",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/364.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/364.png"
                    },
                    {
                        "id":  365,
                        "name":  "Kaimorse",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/365.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/365.png"
                    },
                    {
                        "id":  366,
                        "name":  "Coquiperl",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/366.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/366.png"
                    },
                    {
                        "id":  367,
                        "name":  "Serpang",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/367.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/367.png"
                    },
                    {
                        "id":  368,
                        "name":  "Rosabyss",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/368.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/368.png"
                    },
                    {
                        "id":  369,
                        "name":  "Relicanth",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/369.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/369.png"
                    },
                    {
                        "id":  370,
                        "name":  "Lovdisc",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/370.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/370.png"
                    },
                    {
                        "id":  371,
                        "name":  "Draby",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/371.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/371.png"
                    },
                    {
                        "id":  372,
                        "name":  "Drackhaus",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/372.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/372.png"
                    },
                    {
                        "id":  373,
                        "name":  "Drattak",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/373.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/373.png"
                    },
                    {
                        "id":  374,
                        "name":  "Terhal",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/374.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/374.png"
                    },
                    {
                        "id":  375,
                        "name":  "Métang",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/375.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/375.png"
                    },
                    {
                        "id":  376,
                        "name":  "Métalosse",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/376.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/376.png"
                    },
                    {
                        "id":  377,
                        "name":  "Regirock",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/377.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/377.png"
                    },
                    {
                        "id":  378,
                        "name":  "Regice",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/378.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/378.png"
                    },
                    {
                        "id":  379,
                        "name":  "Registeel",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/379.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/379.png"
                    },
                    {
                        "id":  380,
                        "name":  "Latias",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/380.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/380.png"
                    },
                    {
                        "id":  381,
                        "name":  "Latios",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/381.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/381.png"
                    },
                    {
                        "id":  382,
                        "name":  "Kyogre",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/382.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/382.png"
                    },
                    {
                        "id":  383,
                        "name":  "Groudon",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/383.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/383.png"
                    },
                    {
                        "id":  384,
                        "name":  "Rayquaza",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/384.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/384.png"
                    },
                    {
                        "id":  385,
                        "name":  "Jirachi",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/385.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/385.png"
                    },
                    {
                        "id":  386,
                        "name":  "Deoxys",
                        "region":  "Hoenn",
                        "generation":  3,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/386.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/386.png"
                    },
                    {
                        "id":  387,
                        "name":  "Tortipouss",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/387.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/387.png"
                    },
                    {
                        "id":  388,
                        "name":  "Boskara",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/388.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/388.png"
                    },
                    {
                        "id":  389,
                        "name":  "Torterra",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/389.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/389.png"
                    },
                    {
                        "id":  390,
                        "name":  "Ouisticram",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/390.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/390.png"
                    },
                    {
                        "id":  391,
                        "name":  "Chimpenfeu",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/391.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/391.png"
                    },
                    {
                        "id":  392,
                        "name":  "Simiabraz",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/392.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/392.png"
                    },
                    {
                        "id":  393,
                        "name":  "Tiplouf",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/393.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/393.png"
                    },
                    {
                        "id":  394,
                        "name":  "Prinplouf",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/394.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/394.png"
                    },
                    {
                        "id":  395,
                        "name":  "Pingoléon",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/395.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/395.png"
                    },
                    {
                        "id":  396,
                        "name":  "Étourmi",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/396.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/396.png"
                    },
                    {
                        "id":  397,
                        "name":  "Étourvol",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/397.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/397.png"
                    },
                    {
                        "id":  398,
                        "name":  "Étouraptor",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/398.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/398.png"
                    },
                    {
                        "id":  399,
                        "name":  "Keunotor",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/399.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/399.png"
                    },
                    {
                        "id":  400,
                        "name":  "Castorno",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/400.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/400.png"
                    },
                    {
                        "id":  401,
                        "name":  "Crikzik",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/401.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/401.png"
                    },
                    {
                        "id":  402,
                        "name":  "Mélokrik",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/402.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/402.png"
                    },
                    {
                        "id":  403,
                        "name":  "Lixy",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/403.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/403.png"
                    },
                    {
                        "id":  404,
                        "name":  "Luxio",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/404.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/404.png"
                    },
                    {
                        "id":  405,
                        "name":  "Luxray",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/405.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/405.png"
                    },
                    {
                        "id":  406,
                        "name":  "Rozbouton",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/406.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/406.png"
                    },
                    {
                        "id":  407,
                        "name":  "Roserade",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/407.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/407.png"
                    },
                    {
                        "id":  408,
                        "name":  "Kranidos",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/408.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/408.png"
                    },
                    {
                        "id":  409,
                        "name":  "Charkos",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/409.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/409.png"
                    },
                    {
                        "id":  410,
                        "name":  "Dinoclier",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/410.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/410.png"
                    },
                    {
                        "id":  411,
                        "name":  "Bastiodon",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/411.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/411.png"
                    },
                    {
                        "id":  412,
                        "name":  "Cheniti",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/412.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/412.png"
                    },
                    {
                        "id":  413,
                        "name":  "Cheniselle",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/413.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/413.png"
                    },
                    {
                        "id":  414,
                        "name":  "Papilord",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/414.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/414.png"
                    },
                    {
                        "id":  415,
                        "name":  "Apitrini",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/415.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/415.png"
                    },
                    {
                        "id":  416,
                        "name":  "Apireine",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/416.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/416.png"
                    },
                    {
                        "id":  417,
                        "name":  "Pachirisu",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/417.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/417.png"
                    },
                    {
                        "id":  418,
                        "name":  "Mustébouée",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/418.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/418.png"
                    },
                    {
                        "id":  419,
                        "name":  "Mustéflott",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/419.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/419.png"
                    },
                    {
                        "id":  420,
                        "name":  "Ceribou",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/420.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/420.png"
                    },
                    {
                        "id":  421,
                        "name":  "Ceriflor",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/421.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/421.png"
                    },
                    {
                        "id":  422,
                        "name":  "Sancoki",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/422.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/422.png"
                    },
                    {
                        "id":  423,
                        "name":  "Tritosor",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/423.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/423.png"
                    },
                    {
                        "id":  424,
                        "name":  "Capidextre",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/424.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/424.png"
                    },
                    {
                        "id":  425,
                        "name":  "Baudrive",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/425.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/425.png"
                    },
                    {
                        "id":  426,
                        "name":  "Grodrive",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/426.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/426.png"
                    },
                    {
                        "id":  427,
                        "name":  "Laporeille",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/427.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/427.png"
                    },
                    {
                        "id":  428,
                        "name":  "Lockpin",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/428.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/428.png"
                    },
                    {
                        "id":  429,
                        "name":  "Magirêve",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/429.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/429.png"
                    },
                    {
                        "id":  430,
                        "name":  "Corboss",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/430.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/430.png"
                    },
                    {
                        "id":  431,
                        "name":  "Chaglam",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/431.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/431.png"
                    },
                    {
                        "id":  432,
                        "name":  "Chaffreux",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/432.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/432.png"
                    },
                    {
                        "id":  433,
                        "name":  "Korillon",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/433.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/433.png"
                    },
                    {
                        "id":  434,
                        "name":  "Moufouette",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/434.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/434.png"
                    },
                    {
                        "id":  435,
                        "name":  "Moufflair",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/435.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/435.png"
                    },
                    {
                        "id":  436,
                        "name":  "Archéomire",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/436.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/436.png"
                    },
                    {
                        "id":  437,
                        "name":  "Archéodong",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/437.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/437.png"
                    },
                    {
                        "id":  438,
                        "name":  "Manzaï",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/438.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/438.png"
                    },
                    {
                        "id":  439,
                        "name":  "Mime Jr",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/439.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/439.png"
                    },
                    {
                        "id":  440,
                        "name":  "Ptiravi",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/440.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/440.png"
                    },
                    {
                        "id":  441,
                        "name":  "Pijako",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/441.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/441.png"
                    },
                    {
                        "id":  442,
                        "name":  "Spiritomb",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/442.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/442.png"
                    },
                    {
                        "id":  443,
                        "name":  "Griknot",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/443.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/443.png"
                    },
                    {
                        "id":  444,
                        "name":  "Carmache",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/444.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/444.png"
                    },
                    {
                        "id":  445,
                        "name":  "Carchacrok",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/445.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/445.png"
                    },
                    {
                        "id":  446,
                        "name":  "Goinfrex",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/446.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/446.png"
                    },
                    {
                        "id":  447,
                        "name":  "Riolu",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/447.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/447.png"
                    },
                    {
                        "id":  448,
                        "name":  "Lucario",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/448.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/448.png"
                    },
                    {
                        "id":  449,
                        "name":  "Hippopotas",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/449.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/449.png"
                    },
                    {
                        "id":  450,
                        "name":  "Hippodocus",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/450.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/450.png"
                    },
                    {
                        "id":  451,
                        "name":  "Rapion",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/451.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/451.png"
                    },
                    {
                        "id":  452,
                        "name":  "Drascore",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/452.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/452.png"
                    },
                    {
                        "id":  453,
                        "name":  "Cradopaud",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/453.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/453.png"
                    },
                    {
                        "id":  454,
                        "name":  "Coatox",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/454.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/454.png"
                    },
                    {
                        "id":  455,
                        "name":  "Vortente",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/455.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/455.png"
                    },
                    {
                        "id":  456,
                        "name":  "Écayon",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/456.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/456.png"
                    },
                    {
                        "id":  457,
                        "name":  "Luminéon",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/457.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/457.png"
                    },
                    {
                        "id":  458,
                        "name":  "Babimanta",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/458.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/458.png"
                    },
                    {
                        "id":  459,
                        "name":  "Blizzi",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/459.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/459.png"
                    },
                    {
                        "id":  460,
                        "name":  "Blizzaroi",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/460.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/460.png"
                    },
                    {
                        "id":  461,
                        "name":  "Dimoret",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/461.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/461.png"
                    },
                    {
                        "id":  462,
                        "name":  "Magnézone",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/462.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/462.png"
                    },
                    {
                        "id":  463,
                        "name":  "Coudlangue",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/463.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/463.png"
                    },
                    {
                        "id":  464,
                        "name":  "Rhinastoc",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/464.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/464.png"
                    },
                    {
                        "id":  465,
                        "name":  "Bouldeneu",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/465.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/465.png"
                    },
                    {
                        "id":  466,
                        "name":  "Élekable",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/466.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/466.png"
                    },
                    {
                        "id":  467,
                        "name":  "Maganon",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/467.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/467.png"
                    },
                    {
                        "id":  468,
                        "name":  "Togekiss",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/468.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/468.png"
                    },
                    {
                        "id":  469,
                        "name":  "Yanmega",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/469.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/469.png"
                    },
                    {
                        "id":  470,
                        "name":  "Phyllali",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/470.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/470.png"
                    },
                    {
                        "id":  471,
                        "name":  "Givrali",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/471.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/471.png"
                    },
                    {
                        "id":  472,
                        "name":  "Scorvol",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/472.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/472.png"
                    },
                    {
                        "id":  473,
                        "name":  "Mammochon",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/473.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/473.png"
                    },
                    {
                        "id":  474,
                        "name":  "Porygon-Z",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/474.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/474.png"
                    },
                    {
                        "id":  475,
                        "name":  "Gallame",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/475.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/475.png"
                    },
                    {
                        "id":  476,
                        "name":  "Tarinorme",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/476.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/476.png"
                    },
                    {
                        "id":  477,
                        "name":  "Noctunoir",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/477.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/477.png"
                    },
                    {
                        "id":  478,
                        "name":  "Momartik",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/478.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/478.png"
                    },
                    {
                        "id":  479,
                        "name":  "Motisma",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/479.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/479.png"
                    },
                    {
                        "id":  480,
                        "name":  "Créhelf",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/480.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/480.png"
                    },
                    {
                        "id":  481,
                        "name":  "Créfollet",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/481.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/481.png"
                    },
                    {
                        "id":  482,
                        "name":  "Créfadet",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/482.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/482.png"
                    },
                    {
                        "id":  483,
                        "name":  "Dialga",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/483.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/483.png"
                    },
                    {
                        "id":  484,
                        "name":  "Palkia",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/484.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/484.png"
                    },
                    {
                        "id":  485,
                        "name":  "Heatran",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/485.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/485.png"
                    },
                    {
                        "id":  486,
                        "name":  "Regigigas",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/486.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/486.png"
                    },
                    {
                        "id":  487,
                        "name":  "Giratina",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/487.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/487.png"
                    },
                    {
                        "id":  488,
                        "name":  "Cresselia",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/488.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/488.png"
                    },
                    {
                        "id":  489,
                        "name":  "Phione",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/489.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/489.png"
                    },
                    {
                        "id":  490,
                        "name":  "Manaphy",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/490.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/490.png"
                    },
                    {
                        "id":  491,
                        "name":  "Darkrai",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/491.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/491.png"
                    },
                    {
                        "id":  492,
                        "name":  "Shaymin",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/492.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/492.png"
                    },
                    {
                        "id":  493,
                        "name":  "Arceus",
                        "region":  "Sinnoh",
                        "generation":  4,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/493.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/493.png"
                    },
                    {
                        "id":  494,
                        "name":  "Victini",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/494.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/494.png"
                    },
                    {
                        "id":  495,
                        "name":  "Vipélierre",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/495.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/495.png"
                    },
                    {
                        "id":  496,
                        "name":  "Lianaja",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/496.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/496.png"
                    },
                    {
                        "id":  497,
                        "name":  "Majaspic",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/497.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/497.png"
                    },
                    {
                        "id":  498,
                        "name":  "Gruikui",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/498.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/498.png"
                    },
                    {
                        "id":  499,
                        "name":  "Grotichon",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/499.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/499.png"
                    },
                    {
                        "id":  500,
                        "name":  "Roitiflam",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/500.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/500.png"
                    },
                    {
                        "id":  501,
                        "name":  "Moustillon",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/501.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/501.png"
                    },
                    {
                        "id":  502,
                        "name":  "Mateloutre",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/502.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/502.png"
                    },
                    {
                        "id":  503,
                        "name":  "Clamiral",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/503.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/503.png"
                    },
                    {
                        "id":  504,
                        "name":  "Ratentif",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/504.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/504.png"
                    },
                    {
                        "id":  505,
                        "name":  "Miradar",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/505.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/505.png"
                    },
                    {
                        "id":  506,
                        "name":  "Ponchiot",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/506.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/506.png"
                    },
                    {
                        "id":  507,
                        "name":  "Ponchien",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/507.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/507.png"
                    },
                    {
                        "id":  508,
                        "name":  "Mastouffe",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/508.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/508.png"
                    },
                    {
                        "id":  509,
                        "name":  "Chacripan",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/509.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/509.png"
                    },
                    {
                        "id":  510,
                        "name":  "Léopardus",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/510.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/510.png"
                    },
                    {
                        "id":  511,
                        "name":  "Feuillajou",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/511.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/511.png"
                    },
                    {
                        "id":  512,
                        "name":  "Feuiloutan",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/512.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/512.png"
                    },
                    {
                        "id":  513,
                        "name":  "Flamajou",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/513.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/513.png"
                    },
                    {
                        "id":  514,
                        "name":  "Flamoutan",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/514.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/514.png"
                    },
                    {
                        "id":  515,
                        "name":  "Flotajou",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/515.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/515.png"
                    },
                    {
                        "id":  516,
                        "name":  "Flotoutan",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/516.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/516.png"
                    },
                    {
                        "id":  517,
                        "name":  "Munna",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/517.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/517.png"
                    },
                    {
                        "id":  518,
                        "name":  "Mushana",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/518.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/518.png"
                    },
                    {
                        "id":  519,
                        "name":  "Poichigeon",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/519.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/519.png"
                    },
                    {
                        "id":  520,
                        "name":  "Colombeau",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/520.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/520.png"
                    },
                    {
                        "id":  521,
                        "name":  "Déflaisan",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/521.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/521.png"
                    },
                    {
                        "id":  522,
                        "name":  "Zébibron",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/522.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/522.png"
                    },
                    {
                        "id":  523,
                        "name":  "Zéblitz",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/523.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/523.png"
                    },
                    {
                        "id":  524,
                        "name":  "Nodulithe",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/524.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/524.png"
                    },
                    {
                        "id":  525,
                        "name":  "Géolithe",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/525.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/525.png"
                    },
                    {
                        "id":  526,
                        "name":  "Gigalithe",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/526.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/526.png"
                    },
                    {
                        "id":  527,
                        "name":  "Chovsourir",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/527.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/527.png"
                    },
                    {
                        "id":  528,
                        "name":  "Rhinolove",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/528.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/528.png"
                    },
                    {
                        "id":  529,
                        "name":  "Rototaupe",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/529.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/529.png"
                    },
                    {
                        "id":  530,
                        "name":  "Minotaupe",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/530.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/530.png"
                    },
                    {
                        "id":  531,
                        "name":  "Nanméouïe",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/531.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/531.png"
                    },
                    {
                        "id":  532,
                        "name":  "Charpenti",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/532.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/532.png"
                    },
                    {
                        "id":  533,
                        "name":  "Ouvrifier",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/533.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/533.png"
                    },
                    {
                        "id":  534,
                        "name":  "Bétochef",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/534.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/534.png"
                    },
                    {
                        "id":  535,
                        "name":  "Tritonde",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/535.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/535.png"
                    },
                    {
                        "id":  536,
                        "name":  "Batracné",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/536.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/536.png"
                    },
                    {
                        "id":  537,
                        "name":  "Crapustule",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/537.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/537.png"
                    },
                    {
                        "id":  538,
                        "name":  "Judokrak",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/538.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/538.png"
                    },
                    {
                        "id":  539,
                        "name":  "Karaclée",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/539.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/539.png"
                    },
                    {
                        "id":  540,
                        "name":  "Larveyette",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/540.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/540.png"
                    },
                    {
                        "id":  541,
                        "name":  "Couverdure",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/541.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/541.png"
                    },
                    {
                        "id":  542,
                        "name":  "Manternel",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/542.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/542.png"
                    },
                    {
                        "id":  543,
                        "name":  "Venipatte",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/543.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/543.png"
                    },
                    {
                        "id":  544,
                        "name":  "Scobolide",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/544.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/544.png"
                    },
                    {
                        "id":  545,
                        "name":  "Brutapode",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/545.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/545.png"
                    },
                    {
                        "id":  546,
                        "name":  "Doudouvet",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/546.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/546.png"
                    },
                    {
                        "id":  547,
                        "name":  "Farfaduvet",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/547.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/547.png"
                    },
                    {
                        "id":  548,
                        "name":  "Chlorobule",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/548.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/548.png"
                    },
                    {
                        "id":  549,
                        "name":  "Fragilady",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/549.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/549.png"
                    },
                    {
                        "id":  550,
                        "name":  "Bargantua",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/550.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/550.png"
                    },
                    {
                        "id":  551,
                        "name":  "Mascaïman",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/551.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/551.png"
                    },
                    {
                        "id":  552,
                        "name":  "Escroco",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/552.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/552.png"
                    },
                    {
                        "id":  553,
                        "name":  "Crocorible",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/553.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/553.png"
                    },
                    {
                        "id":  554,
                        "name":  "Darumarond",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/554.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/554.png"
                    },
                    {
                        "id":  555,
                        "name":  "Darumacho",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/555.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/555.png"
                    },
                    {
                        "id":  556,
                        "name":  "Maracachi",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/556.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/556.png"
                    },
                    {
                        "id":  557,
                        "name":  "Crabicoque",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/557.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/557.png"
                    },
                    {
                        "id":  558,
                        "name":  "Crabaraque",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/558.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/558.png"
                    },
                    {
                        "id":  559,
                        "name":  "Baggiguane",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/559.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/559.png"
                    },
                    {
                        "id":  560,
                        "name":  "Baggaïd",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/560.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/560.png"
                    },
                    {
                        "id":  561,
                        "name":  "Cryptéro",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/561.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/561.png"
                    },
                    {
                        "id":  562,
                        "name":  "Tutafeh",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/562.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/562.png"
                    },
                    {
                        "id":  563,
                        "name":  "Tutankafer",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/563.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/563.png"
                    },
                    {
                        "id":  564,
                        "name":  "Carapagos",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/564.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/564.png"
                    },
                    {
                        "id":  565,
                        "name":  "Mégapagos",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/565.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/565.png"
                    },
                    {
                        "id":  566,
                        "name":  "Arkéapti",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/566.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/566.png"
                    },
                    {
                        "id":  567,
                        "name":  "Aéroptéryx",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/567.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/567.png"
                    },
                    {
                        "id":  568,
                        "name":  "Miamiasme",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/568.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/568.png"
                    },
                    {
                        "id":  569,
                        "name":  "Miasmax",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/569.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/569.png"
                    },
                    {
                        "id":  570,
                        "name":  "Zorua",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/570.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/570.png"
                    },
                    {
                        "id":  571,
                        "name":  "Zoroark",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/571.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/571.png"
                    },
                    {
                        "id":  572,
                        "name":  "Chinchidou",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/572.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/572.png"
                    },
                    {
                        "id":  573,
                        "name":  "Pashmilla",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/573.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/573.png"
                    },
                    {
                        "id":  574,
                        "name":  "Scrutella",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/574.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/574.png"
                    },
                    {
                        "id":  575,
                        "name":  "Mesmérella",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/575.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/575.png"
                    },
                    {
                        "id":  576,
                        "name":  "Sidérella",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/576.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/576.png"
                    },
                    {
                        "id":  577,
                        "name":  "Nucléos",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/577.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/577.png"
                    },
                    {
                        "id":  578,
                        "name":  "Méios",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/578.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/578.png"
                    },
                    {
                        "id":  579,
                        "name":  "Symbios",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/579.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/579.png"
                    },
                    {
                        "id":  580,
                        "name":  "Couaneton",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/580.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/580.png"
                    },
                    {
                        "id":  581,
                        "name":  "Lakmécygne",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/581.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/581.png"
                    },
                    {
                        "id":  582,
                        "name":  "Sorbébé",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/582.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/582.png"
                    },
                    {
                        "id":  583,
                        "name":  "Sorboul",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/583.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/583.png"
                    },
                    {
                        "id":  584,
                        "name":  "Sorbouboul",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/584.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/584.png"
                    },
                    {
                        "id":  585,
                        "name":  "Vivaldaim",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/585.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/585.png"
                    },
                    {
                        "id":  586,
                        "name":  "Haydaim",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/586.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/586.png"
                    },
                    {
                        "id":  587,
                        "name":  "Emolga",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/587.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/587.png"
                    },
                    {
                        "id":  588,
                        "name":  "Carabing",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/588.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/588.png"
                    },
                    {
                        "id":  589,
                        "name":  "Lançargot",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/589.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/589.png"
                    },
                    {
                        "id":  590,
                        "name":  "Trompignon",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/590.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/590.png"
                    },
                    {
                        "id":  591,
                        "name":  "Gaulet",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/591.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/591.png"
                    },
                    {
                        "id":  592,
                        "name":  "Viskuse",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/592.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/592.png"
                    },
                    {
                        "id":  593,
                        "name":  "Moyade",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/593.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/593.png"
                    },
                    {
                        "id":  594,
                        "name":  "Mamanbo",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/594.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/594.png"
                    },
                    {
                        "id":  595,
                        "name":  "Statitik",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/595.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/595.png"
                    },
                    {
                        "id":  596,
                        "name":  "Mygavolt",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/596.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/596.png"
                    },
                    {
                        "id":  597,
                        "name":  "Grindur",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/597.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/597.png"
                    },
                    {
                        "id":  598,
                        "name":  "Noacier",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/598.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/598.png"
                    },
                    {
                        "id":  599,
                        "name":  "Tic",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/599.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/599.png"
                    },
                    {
                        "id":  600,
                        "name":  "Clic",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/600.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/600.png"
                    },
                    {
                        "id":  601,
                        "name":  "Cliticlic",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/601.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/601.png"
                    },
                    {
                        "id":  602,
                        "name":  "Anchwatt",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/602.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/602.png"
                    },
                    {
                        "id":  603,
                        "name":  "Lampéroie",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/603.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/603.png"
                    },
                    {
                        "id":  604,
                        "name":  "Ohmassacre",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/604.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/604.png"
                    },
                    {
                        "id":  605,
                        "name":  "Lewsor",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/605.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/605.png"
                    },
                    {
                        "id":  606,
                        "name":  "Neitram",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/606.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/606.png"
                    },
                    {
                        "id":  607,
                        "name":  "Funécire",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/607.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/607.png"
                    },
                    {
                        "id":  608,
                        "name":  "Mélancolux",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/608.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/608.png"
                    },
                    {
                        "id":  609,
                        "name":  "Lugulabre",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/609.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/609.png"
                    },
                    {
                        "id":  610,
                        "name":  "Coupenotte",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/610.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/610.png"
                    },
                    {
                        "id":  611,
                        "name":  "Incisache",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/611.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/611.png"
                    },
                    {
                        "id":  612,
                        "name":  "Tranchodon",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/612.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/612.png"
                    },
                    {
                        "id":  613,
                        "name":  "Polarhume",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/613.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/613.png"
                    },
                    {
                        "id":  614,
                        "name":  "Polagriffe",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/614.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/614.png"
                    },
                    {
                        "id":  615,
                        "name":  "Hexagel",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/615.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/615.png"
                    },
                    {
                        "id":  616,
                        "name":  "Escargaume",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/616.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/616.png"
                    },
                    {
                        "id":  617,
                        "name":  "Limaspeed",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/617.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/617.png"
                    },
                    {
                        "id":  618,
                        "name":  "Limonde",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/618.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/618.png"
                    },
                    {
                        "id":  619,
                        "name":  "Kungfouine",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/619.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/619.png"
                    },
                    {
                        "id":  620,
                        "name":  "Shaofouine",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/620.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/620.png"
                    },
                    {
                        "id":  621,
                        "name":  "Drakkarmin",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/621.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/621.png"
                    },
                    {
                        "id":  622,
                        "name":  "Gringolem",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/622.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/622.png"
                    },
                    {
                        "id":  623,
                        "name":  "Golemastoc",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/623.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/623.png"
                    },
                    {
                        "id":  624,
                        "name":  "Scalpion",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/624.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/624.png"
                    },
                    {
                        "id":  625,
                        "name":  "Scalproie",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/625.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/625.png"
                    },
                    {
                        "id":  626,
                        "name":  "Frison",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/626.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/626.png"
                    },
                    {
                        "id":  627,
                        "name":  "Furaiglon",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/627.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/627.png"
                    },
                    {
                        "id":  628,
                        "name":  "Gueriaigle",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/628.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/628.png"
                    },
                    {
                        "id":  629,
                        "name":  "Vostourno",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/629.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/629.png"
                    },
                    {
                        "id":  630,
                        "name":  "Vaututrice",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/630.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/630.png"
                    },
                    {
                        "id":  631,
                        "name":  "Aflamanoir",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/631.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/631.png"
                    },
                    {
                        "id":  632,
                        "name":  "Fermite",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/632.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/632.png"
                    },
                    {
                        "id":  633,
                        "name":  "Solochi",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/633.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/633.png"
                    },
                    {
                        "id":  634,
                        "name":  "Diamat",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/634.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/634.png"
                    },
                    {
                        "id":  635,
                        "name":  "Trioxhydre",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/635.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/635.png"
                    },
                    {
                        "id":  636,
                        "name":  "Pyronille",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/636.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/636.png"
                    },
                    {
                        "id":  637,
                        "name":  "Pyrax",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/637.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/637.png"
                    },
                    {
                        "id":  638,
                        "name":  "Cobaltium",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/638.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/638.png"
                    },
                    {
                        "id":  639,
                        "name":  "Terrakium",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/639.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/639.png"
                    },
                    {
                        "id":  640,
                        "name":  "Viridium",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/640.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/640.png"
                    },
                    {
                        "id":  641,
                        "name":  "Boréas",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/641.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/641.png"
                    },
                    {
                        "id":  642,
                        "name":  "Fulguris",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/642.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/642.png"
                    },
                    {
                        "id":  643,
                        "name":  "Reshiram",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/643.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/643.png"
                    },
                    {
                        "id":  644,
                        "name":  "Zekrom",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/644.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/644.png"
                    },
                    {
                        "id":  645,
                        "name":  "Démétéros",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/645.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/645.png"
                    },
                    {
                        "id":  646,
                        "name":  "Kyurem",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/646.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/646.png"
                    },
                    {
                        "id":  647,
                        "name":  "Keldeo",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/647.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/647.png"
                    },
                    {
                        "id":  648,
                        "name":  "Meloetta",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/648.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/648.png"
                    },
                    {
                        "id":  649,
                        "name":  "Genesect",
                        "region":  "Unys",
                        "generation":  5,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/649.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/649.png"
                    },
                    {
                        "id":  650,
                        "name":  "Marisson",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/650.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/650.png"
                    },
                    {
                        "id":  651,
                        "name":  "Boguérisse",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/651.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/651.png"
                    },
                    {
                        "id":  652,
                        "name":  "Blindépique",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/652.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/652.png"
                    },
                    {
                        "id":  653,
                        "name":  "Feunnec",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/653.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/653.png"
                    },
                    {
                        "id":  654,
                        "name":  "Roussil",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/654.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/654.png"
                    },
                    {
                        "id":  655,
                        "name":  "Goupelin",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/655.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/655.png"
                    },
                    {
                        "id":  656,
                        "name":  "Grenousse",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/656.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/656.png"
                    },
                    {
                        "id":  657,
                        "name":  "Croâporal",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/657.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/657.png"
                    },
                    {
                        "id":  658,
                        "name":  "Amphinobi",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/658.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/658.png"
                    },
                    {
                        "id":  659,
                        "name":  "Sapereau",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/659.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/659.png"
                    },
                    {
                        "id":  660,
                        "name":  "Excavarenne",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/660.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/660.png"
                    },
                    {
                        "id":  661,
                        "name":  "Passerouge",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/661.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/661.png"
                    },
                    {
                        "id":  662,
                        "name":  "Braisillon",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/662.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/662.png"
                    },
                    {
                        "id":  663,
                        "name":  "Flambusard",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/663.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/663.png"
                    },
                    {
                        "id":  664,
                        "name":  "Lépidonille",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/664.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/664.png"
                    },
                    {
                        "id":  665,
                        "name":  "Pérégrain",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/665.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/665.png"
                    },
                    {
                        "id":  666,
                        "name":  "Prismillon",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/666.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/666.png"
                    },
                    {
                        "id":  667,
                        "name":  "Hélionceau",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/667.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/667.png"
                    },
                    {
                        "id":  668,
                        "name":  "Némélios",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/668.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/668.png"
                    },
                    {
                        "id":  669,
                        "name":  "Flabébé",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/669.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/669.png"
                    },
                    {
                        "id":  670,
                        "name":  "Floette",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/670.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/670.png"
                    },
                    {
                        "id":  671,
                        "name":  "Florges",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/671.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/671.png"
                    },
                    {
                        "id":  672,
                        "name":  "Cabriolaine",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/672.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/672.png"
                    },
                    {
                        "id":  673,
                        "name":  "Chevroum",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/673.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/673.png"
                    },
                    {
                        "id":  674,
                        "name":  "Pandespiègle",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/674.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/674.png"
                    },
                    {
                        "id":  675,
                        "name":  "Pandarbare",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/675.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/675.png"
                    },
                    {
                        "id":  676,
                        "name":  "Couafarel",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/676.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/676.png"
                    },
                    {
                        "id":  677,
                        "name":  "Psystigri",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/677.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/677.png"
                    },
                    {
                        "id":  678,
                        "name":  "Mistigrix",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/678.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/678.png"
                    },
                    {
                        "id":  679,
                        "name":  "Monorpale",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/679.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/679.png"
                    },
                    {
                        "id":  680,
                        "name":  "Dimoclès",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/680.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/680.png"
                    },
                    {
                        "id":  681,
                        "name":  "Exagide",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/681.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/681.png"
                    },
                    {
                        "id":  682,
                        "name":  "Fluvetin",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/682.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/682.png"
                    },
                    {
                        "id":  683,
                        "name":  "Cocotine",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/683.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/683.png"
                    },
                    {
                        "id":  684,
                        "name":  "Sucroquin",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/684.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/684.png"
                    },
                    {
                        "id":  685,
                        "name":  "Cupcanaille",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/685.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/685.png"
                    },
                    {
                        "id":  686,
                        "name":  "Sepiatop",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/686.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/686.png"
                    },
                    {
                        "id":  687,
                        "name":  "Sepiatroce",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/687.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/687.png"
                    },
                    {
                        "id":  688,
                        "name":  "Opermine",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/688.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/688.png"
                    },
                    {
                        "id":  689,
                        "name":  "Golgopathe",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/689.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/689.png"
                    },
                    {
                        "id":  690,
                        "name":  "Venalgue",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/690.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/690.png"
                    },
                    {
                        "id":  691,
                        "name":  "Kravarech",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/691.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/691.png"
                    },
                    {
                        "id":  692,
                        "name":  "Flingouste",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/692.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/692.png"
                    },
                    {
                        "id":  693,
                        "name":  "Gamblast",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/693.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/693.png"
                    },
                    {
                        "id":  694,
                        "name":  "Galvaran",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/694.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/694.png"
                    },
                    {
                        "id":  695,
                        "name":  "Iguolta",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/695.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/695.png"
                    },
                    {
                        "id":  696,
                        "name":  "Ptyranidur",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/696.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/696.png"
                    },
                    {
                        "id":  697,
                        "name":  "Rexillius",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/697.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/697.png"
                    },
                    {
                        "id":  698,
                        "name":  "Amagara",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/698.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/698.png"
                    },
                    {
                        "id":  699,
                        "name":  "Dragmara",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/699.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/699.png"
                    },
                    {
                        "id":  700,
                        "name":  "Nymphali",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/700.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/700.png"
                    },
                    {
                        "id":  701,
                        "name":  "Brutalibré",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/701.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/701.png"
                    },
                    {
                        "id":  702,
                        "name":  "Dedenne",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/702.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/702.png"
                    },
                    {
                        "id":  703,
                        "name":  "Strassie",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/703.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/703.png"
                    },
                    {
                        "id":  704,
                        "name":  "Mucuscule",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/704.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/704.png"
                    },
                    {
                        "id":  705,
                        "name":  "Colimucus",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/705.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/705.png"
                    },
                    {
                        "id":  706,
                        "name":  "Muplodocus",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/706.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/706.png"
                    },
                    {
                        "id":  707,
                        "name":  "Trousselin",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/707.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/707.png"
                    },
                    {
                        "id":  708,
                        "name":  "Brocélôme",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/708.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/708.png"
                    },
                    {
                        "id":  709,
                        "name":  "Desséliande",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/709.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/709.png"
                    },
                    {
                        "id":  710,
                        "name":  "Pitrouille",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/710.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/710.png"
                    },
                    {
                        "id":  711,
                        "name":  "Banshitrouye",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/711.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/711.png"
                    },
                    {
                        "id":  712,
                        "name":  "Grelaçon",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/712.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/712.png"
                    },
                    {
                        "id":  713,
                        "name":  "Séracrawl",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/713.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/713.png"
                    },
                    {
                        "id":  714,
                        "name":  "Sonistrelle",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/714.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/714.png"
                    },
                    {
                        "id":  715,
                        "name":  "Bruyverne",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/715.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/715.png"
                    },
                    {
                        "id":  716,
                        "name":  "Xerneas",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/716.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/716.png"
                    },
                    {
                        "id":  717,
                        "name":  "Yveltal",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/717.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/717.png"
                    },
                    {
                        "id":  718,
                        "name":  "Zygarde",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/718.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/718.png"
                    },
                    {
                        "id":  719,
                        "name":  "Diancie",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/719.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/719.png"
                    },
                    {
                        "id":  720,
                        "name":  "Hoopa",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/720.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/720.png"
                    },
                    {
                        "id":  721,
                        "name":  "Volcanion",
                        "region":  "Kalos",
                        "generation":  6,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/721.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/721.png"
                    },
                    {
                        "id":  722,
                        "name":  "Brindibou",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/722.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/722.png"
                    },
                    {
                        "id":  723,
                        "name":  "Efflèche",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/723.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/723.png"
                    },
                    {
                        "id":  724,
                        "name":  "Archéduc",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/724.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/724.png"
                    },
                    {
                        "id":  725,
                        "name":  "Flamiaou",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/725.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/725.png"
                    },
                    {
                        "id":  726,
                        "name":  "Matoufeu",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/726.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/726.png"
                    },
                    {
                        "id":  727,
                        "name":  "Félinferno",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/727.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/727.png"
                    },
                    {
                        "id":  728,
                        "name":  "Otaquin",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/728.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/728.png"
                    },
                    {
                        "id":  729,
                        "name":  "Otarlette",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/729.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/729.png"
                    },
                    {
                        "id":  730,
                        "name":  "Oratoria",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/730.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/730.png"
                    },
                    {
                        "id":  731,
                        "name":  "Picassaut",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/731.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/731.png"
                    },
                    {
                        "id":  732,
                        "name":  "Piclairon",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/732.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/732.png"
                    },
                    {
                        "id":  733,
                        "name":  "Bazoucan",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/733.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/733.png"
                    },
                    {
                        "id":  734,
                        "name":  "Manglouton",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/734.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/734.png"
                    },
                    {
                        "id":  735,
                        "name":  "Argouste",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/735.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/735.png"
                    },
                    {
                        "id":  736,
                        "name":  "Larvibule",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/736.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/736.png"
                    },
                    {
                        "id":  737,
                        "name":  "Chrysapile",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/737.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/737.png"
                    },
                    {
                        "id":  738,
                        "name":  "Lucanon",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/738.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/738.png"
                    },
                    {
                        "id":  739,
                        "name":  "Crabagarre",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/739.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/739.png"
                    },
                    {
                        "id":  740,
                        "name":  "Crabominable",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/740.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/740.png"
                    },
                    {
                        "id":  741,
                        "name":  "Plumeline",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/741.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/741.png"
                    },
                    {
                        "id":  742,
                        "name":  "Bombydou",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/742.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/742.png"
                    },
                    {
                        "id":  743,
                        "name":  "Rubombelle",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/743.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/743.png"
                    },
                    {
                        "id":  744,
                        "name":  "Rocabot",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/744.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/744.png"
                    },
                    {
                        "id":  745,
                        "name":  "Lougaroc",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/745.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/745.png"
                    },
                    {
                        "id":  746,
                        "name":  "Froussardine",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/746.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/746.png"
                    },
                    {
                        "id":  747,
                        "name":  "Vorastérie",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/747.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/747.png"
                    },
                    {
                        "id":  748,
                        "name":  "Prédastérie",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/748.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/748.png"
                    },
                    {
                        "id":  749,
                        "name":  "Tiboudet",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/749.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/749.png"
                    },
                    {
                        "id":  750,
                        "name":  "Bourrinos",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/750.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/750.png"
                    },
                    {
                        "id":  751,
                        "name":  "Araqua",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/751.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/751.png"
                    },
                    {
                        "id":  752,
                        "name":  "Tarenbulle",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/752.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/752.png"
                    },
                    {
                        "id":  753,
                        "name":  "Mimantis",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/753.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/753.png"
                    },
                    {
                        "id":  754,
                        "name":  "Floramantis",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/754.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/754.png"
                    },
                    {
                        "id":  755,
                        "name":  "Spododo",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/755.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/755.png"
                    },
                    {
                        "id":  756,
                        "name":  "Lampignon",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/756.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/756.png"
                    },
                    {
                        "id":  757,
                        "name":  "Tritox",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/757.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/757.png"
                    },
                    {
                        "id":  758,
                        "name":  "Malamandre",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/758.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/758.png"
                    },
                    {
                        "id":  759,
                        "name":  "Nounourson",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/759.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/759.png"
                    },
                    {
                        "id":  760,
                        "name":  "Chelours",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/760.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/760.png"
                    },
                    {
                        "id":  761,
                        "name":  "Croquine",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/761.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/761.png"
                    },
                    {
                        "id":  762,
                        "name":  "Candine",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/762.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/762.png"
                    },
                    {
                        "id":  763,
                        "name":  "Sucreine",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/763.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/763.png"
                    },
                    {
                        "id":  764,
                        "name":  "Guérilande",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/764.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/764.png"
                    },
                    {
                        "id":  765,
                        "name":  "Gouroutan",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/765.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/765.png"
                    },
                    {
                        "id":  766,
                        "name":  "Quartermac",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/766.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/766.png"
                    },
                    {
                        "id":  767,
                        "name":  "Sovkipou",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/767.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/767.png"
                    },
                    {
                        "id":  768,
                        "name":  "Sarmuraï",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/768.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/768.png"
                    },
                    {
                        "id":  769,
                        "name":  "Bacabouh",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/769.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/769.png"
                    },
                    {
                        "id":  770,
                        "name":  "Trépassable",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/770.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/770.png"
                    },
                    {
                        "id":  771,
                        "name":  "Concombaffe",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/771.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/771.png"
                    },
                    {
                        "id":  772,
                        "name":  "Type:0",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/772.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/772.png"
                    },
                    {
                        "id":  773,
                        "name":  "Silvallié",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/773.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/773.png"
                    },
                    {
                        "id":  774,
                        "name":  "Météno",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/774.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/774.png"
                    },
                    {
                        "id":  775,
                        "name":  "Dodoala",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/775.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/775.png"
                    },
                    {
                        "id":  776,
                        "name":  "Boumata",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/776.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/776.png"
                    },
                    {
                        "id":  777,
                        "name":  "Togedemaru",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/777.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/777.png"
                    },
                    {
                        "id":  778,
                        "name":  "Mimiqui",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/778.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/778.png"
                    },
                    {
                        "id":  779,
                        "name":  "Denticrisse",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/779.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/779.png"
                    },
                    {
                        "id":  780,
                        "name":  "Draïeul",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/780.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/780.png"
                    },
                    {
                        "id":  781,
                        "name":  "Sinistrail",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/781.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/781.png"
                    },
                    {
                        "id":  782,
                        "name":  "Bébécaille",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/782.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/782.png"
                    },
                    {
                        "id":  783,
                        "name":  "Écaïd",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/783.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/783.png"
                    },
                    {
                        "id":  784,
                        "name":  "Ékaïser",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/784.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/784.png"
                    },
                    {
                        "id":  785,
                        "name":  "Tokorico",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/785.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/785.png"
                    },
                    {
                        "id":  786,
                        "name":  "Tokopiyon",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/786.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/786.png"
                    },
                    {
                        "id":  787,
                        "name":  "Tokotoro",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/787.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/787.png"
                    },
                    {
                        "id":  788,
                        "name":  "Tokopisco",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/788.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/788.png"
                    },
                    {
                        "id":  789,
                        "name":  "Cosmog",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/789.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/789.png"
                    },
                    {
                        "id":  790,
                        "name":  "Cosmovum",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/790.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/790.png"
                    },
                    {
                        "id":  791,
                        "name":  "Solgaleo",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/791.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/791.png"
                    },
                    {
                        "id":  792,
                        "name":  "Lunala",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/792.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/792.png"
                    },
                    {
                        "id":  793,
                        "name":  "Zéroïd",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/793.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/793.png"
                    },
                    {
                        "id":  794,
                        "name":  "Mouscoto",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/794.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/794.png"
                    },
                    {
                        "id":  795,
                        "name":  "Cancrelove",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/795.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/795.png"
                    },
                    {
                        "id":  796,
                        "name":  "Câblifère",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/796.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/796.png"
                    },
                    {
                        "id":  797,
                        "name":  "Bamboiselle",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/797.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/797.png"
                    },
                    {
                        "id":  798,
                        "name":  "Katagami",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/798.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/798.png"
                    },
                    {
                        "id":  799,
                        "name":  "Engloutyran",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/799.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/799.png"
                    },
                    {
                        "id":  800,
                        "name":  "Necrozma",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/800.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/800.png"
                    },
                    {
                        "id":  801,
                        "name":  "Magearna",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/801.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/801.png"
                    },
                    {
                        "id":  802,
                        "name":  "Marshadow",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/802.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/802.png"
                    },
                    {
                        "id":  803,
                        "name":  "Vémini",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/803.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/803.png"
                    },
                    {
                        "id":  804,
                        "name":  "Mandrillon",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/804.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/804.png"
                    },
                    {
                        "id":  805,
                        "name":  "Ama-Ama",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/805.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/805.png"
                    },
                    {
                        "id":  806,
                        "name":  "Pierroteknik",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/806.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/806.png"
                    },
                    {
                        "id":  807,
                        "name":  "Zeraora",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/807.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/807.png"
                    },
                    {
                        "id":  808,
                        "name":  "Meltan",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/808.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/808.png"
                    },
                    {
                        "id":  809,
                        "name":  "Melmetal",
                        "region":  "Alola",
                        "generation":  7,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/809.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/809.png"
                    },
                    {
                        "id":  810,
                        "name":  "Ouistempo",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/810.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/810.png"
                    },
                    {
                        "id":  811,
                        "name":  "Badabouin",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/811.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/811.png"
                    },
                    {
                        "id":  812,
                        "name":  "Gorythmic",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/812.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/812.png"
                    },
                    {
                        "id":  813,
                        "name":  "Flambino",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/813.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/813.png"
                    },
                    {
                        "id":  814,
                        "name":  "Lapyro",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/814.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/814.png"
                    },
                    {
                        "id":  815,
                        "name":  "Pyrobut",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/815.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/815.png"
                    },
                    {
                        "id":  816,
                        "name":  "Larméléon",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/816.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/816.png"
                    },
                    {
                        "id":  817,
                        "name":  "Arrozard",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/817.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/817.png"
                    },
                    {
                        "id":  818,
                        "name":  "Lézargus",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/818.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/818.png"
                    },
                    {
                        "id":  819,
                        "name":  "Rongourmand",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/819.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/819.png"
                    },
                    {
                        "id":  820,
                        "name":  "Rongrigou",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/820.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/820.png"
                    },
                    {
                        "id":  821,
                        "name":  "Minisange",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/821.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/821.png"
                    },
                    {
                        "id":  822,
                        "name":  "Bleuseille",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/822.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/822.png"
                    },
                    {
                        "id":  823,
                        "name":  "Corvaillus",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/823.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/823.png"
                    },
                    {
                        "id":  824,
                        "name":  "Larvadar",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/824.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/824.png"
                    },
                    {
                        "id":  825,
                        "name":  "Coléodôme",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/825.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/825.png"
                    },
                    {
                        "id":  826,
                        "name":  "Astronelle",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/826.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/826.png"
                    },
                    {
                        "id":  827,
                        "name":  "Goupilou",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/827.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/827.png"
                    },
                    {
                        "id":  828,
                        "name":  "Roublenard",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/828.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/828.png"
                    },
                    {
                        "id":  829,
                        "name":  "Tournicoton",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/829.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/829.png"
                    },
                    {
                        "id":  830,
                        "name":  "Blancoton",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/830.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/830.png"
                    },
                    {
                        "id":  831,
                        "name":  "Moumouton",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/831.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/831.png"
                    },
                    {
                        "id":  832,
                        "name":  "Moumouflon",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/832.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/832.png"
                    },
                    {
                        "id":  833,
                        "name":  "Khélocrok",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/833.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/833.png"
                    },
                    {
                        "id":  834,
                        "name":  "Torgamord",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/834.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/834.png"
                    },
                    {
                        "id":  835,
                        "name":  "Voltoutou",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/835.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/835.png"
                    },
                    {
                        "id":  836,
                        "name":  "Fulgudog",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/836.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/836.png"
                    },
                    {
                        "id":  837,
                        "name":  "Charbi",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/837.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/837.png"
                    },
                    {
                        "id":  838,
                        "name":  "Wagomine",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/838.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/838.png"
                    },
                    {
                        "id":  839,
                        "name":  "Monthracite",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/839.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/839.png"
                    },
                    {
                        "id":  840,
                        "name":  "Verpom",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/840.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/840.png"
                    },
                    {
                        "id":  841,
                        "name":  "Pomdrapi",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/841.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/841.png"
                    },
                    {
                        "id":  842,
                        "name":  "Dratatin",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/842.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/842.png"
                    },
                    {
                        "id":  843,
                        "name":  "Dunaja",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/843.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/843.png"
                    },
                    {
                        "id":  844,
                        "name":  "Dunaconda",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/844.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/844.png"
                    },
                    {
                        "id":  845,
                        "name":  "Nigosier",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/845.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/845.png"
                    },
                    {
                        "id":  846,
                        "name":  "Embrochet",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/846.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/846.png"
                    },
                    {
                        "id":  847,
                        "name":  "Hastacuda",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/847.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/847.png"
                    },
                    {
                        "id":  848,
                        "name":  "Toxizap",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/848.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/848.png"
                    },
                    {
                        "id":  849,
                        "name":  "Salarsen",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/849.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/849.png"
                    },
                    {
                        "id":  850,
                        "name":  "Grillepattes",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/850.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/850.png"
                    },
                    {
                        "id":  851,
                        "name":  "Scolocendre",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/851.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/851.png"
                    },
                    {
                        "id":  852,
                        "name":  "Poulpaf",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/852.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/852.png"
                    },
                    {
                        "id":  853,
                        "name":  "Krakos",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/853.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/853.png"
                    },
                    {
                        "id":  854,
                        "name":  "Théffroi",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/854.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/854.png"
                    },
                    {
                        "id":  855,
                        "name":  "Polthégeist",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/855.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/855.png"
                    },
                    {
                        "id":  856,
                        "name":  "Bibichut",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/856.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/856.png"
                    },
                    {
                        "id":  857,
                        "name":  "Chapotus",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/857.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/857.png"
                    },
                    {
                        "id":  858,
                        "name":  "Sorcilence",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/858.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/858.png"
                    },
                    {
                        "id":  859,
                        "name":  "Grimalin",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/859.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/859.png"
                    },
                    {
                        "id":  860,
                        "name":  "Fourbelin",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/860.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/860.png"
                    },
                    {
                        "id":  861,
                        "name":  "Angoliath",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/861.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/861.png"
                    },
                    {
                        "id":  862,
                        "name":  "Ixon",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/862.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/862.png"
                    },
                    {
                        "id":  863,
                        "name":  "Berserkatt",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/863.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/863.png"
                    },
                    {
                        "id":  864,
                        "name":  "Corayôme",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/864.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/864.png"
                    },
                    {
                        "id":  865,
                        "name":  "Palarticho",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/865.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/865.png"
                    },
                    {
                        "id":  866,
                        "name":  "M. Glaquette",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/866.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/866.png"
                    },
                    {
                        "id":  867,
                        "name":  "Tutétékri",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/867.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/867.png"
                    },
                    {
                        "id":  868,
                        "name":  "Crèmy",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/868.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/868.png"
                    },
                    {
                        "id":  869,
                        "name":  "Charmilly",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/869.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/869.png"
                    },
                    {
                        "id":  870,
                        "name":  "Hexadron",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/870.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/870.png"
                    },
                    {
                        "id":  871,
                        "name":  "Wattapik",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/871.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/871.png"
                    },
                    {
                        "id":  872,
                        "name":  "Frissonille",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/872.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/872.png"
                    },
                    {
                        "id":  873,
                        "name":  "Beldeneige",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/873.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/873.png"
                    },
                    {
                        "id":  874,
                        "name":  "Dolman",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/874.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/874.png"
                    },
                    {
                        "id":  875,
                        "name":  "Bekaglaçon",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/875.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/875.png"
                    },
                    {
                        "id":  876,
                        "name":  "Wimessir",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/876.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/876.png"
                    },
                    {
                        "id":  877,
                        "name":  "Morpeko",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/877.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/877.png"
                    },
                    {
                        "id":  878,
                        "name":  "Charibari",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/878.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/878.png"
                    },
                    {
                        "id":  879,
                        "name":  "Pachyradjah",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/879.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/879.png"
                    },
                    {
                        "id":  880,
                        "name":  "Galvagon",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/880.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/880.png"
                    },
                    {
                        "id":  881,
                        "name":  "Galvagla",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/881.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/881.png"
                    },
                    {
                        "id":  882,
                        "name":  "Hydragon",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/882.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/882.png"
                    },
                    {
                        "id":  883,
                        "name":  "Hydragla",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/883.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/883.png"
                    },
                    {
                        "id":  884,
                        "name":  "Duralugon",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/884.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/884.png"
                    },
                    {
                        "id":  885,
                        "name":  "Fantyrm",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/885.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/885.png"
                    },
                    {
                        "id":  886,
                        "name":  "Dispareptil",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/886.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/886.png"
                    },
                    {
                        "id":  887,
                        "name":  "Lanssorien",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/887.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/887.png"
                    },
                    {
                        "id":  888,
                        "name":  "Zacian",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/888.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/888.png"
                    },
                    {
                        "id":  889,
                        "name":  "Zamazenta",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/889.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/889.png"
                    },
                    {
                        "id":  890,
                        "name":  "Éthernatos",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/890.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/890.png"
                    },
                    {
                        "id":  891,
                        "name":  "Wushours",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/891.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/891.png"
                    },
                    {
                        "id":  892,
                        "name":  "Shifours",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/892.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/892.png"
                    },
                    {
                        "id":  893,
                        "name":  "Zarude",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/893.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/893.png"
                    },
                    {
                        "id":  894,
                        "name":  "Regieleki",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/894.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/894.png"
                    },
                    {
                        "id":  895,
                        "name":  "Regidrago",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/895.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/895.png"
                    },
                    {
                        "id":  896,
                        "name":  "Blizzeval",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/896.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/896.png"
                    },
                    {
                        "id":  897,
                        "name":  "Spectreval",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/897.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/897.png"
                    },
                    {
                        "id":  898,
                        "name":  "Sylveroy",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/898.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/898.png"
                    },
                    {
                        "id":  899,
                        "name":  "Cerbyllin",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/899.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/899.png"
                    },
                    {
                        "id":  900,
                        "name":  "Hachécateur",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/900.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/900.png"
                    },
                    {
                        "id":  901,
                        "name":  "Ursaking",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/901.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/901.png"
                    },
                    {
                        "id":  902,
                        "name":  "Paragruel",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/902.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/902.png"
                    },
                    {
                        "id":  903,
                        "name":  "Farfurex",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/903.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/903.png"
                    },
                    {
                        "id":  904,
                        "name":  "Qwilpik",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/904.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/904.png"
                    },
                    {
                        "id":  905,
                        "name":  "Amovénus",
                        "region":  "Galar",
                        "generation":  8,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/905.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/905.png"
                    },
                    {
                        "id":  906,
                        "name":  "Poussacha",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/906.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/906.png"
                    },
                    {
                        "id":  907,
                        "name":  "Matourgeon",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/907.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/907.png"
                    },
                    {
                        "id":  908,
                        "name":  "Miascarade",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/908.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/908.png"
                    },
                    {
                        "id":  909,
                        "name":  "Chochodile",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/909.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/909.png"
                    },
                    {
                        "id":  910,
                        "name":  "Crocogril",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/910.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/910.png"
                    },
                    {
                        "id":  911,
                        "name":  "Flâmigator",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/911.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/911.png"
                    },
                    {
                        "id":  912,
                        "name":  "Coiffeton",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/912.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/912.png"
                    },
                    {
                        "id":  913,
                        "name":  "Canarbello",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/913.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/913.png"
                    },
                    {
                        "id":  914,
                        "name":  "Palmaval",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/914.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/914.png"
                    },
                    {
                        "id":  915,
                        "name":  "Gourmelet",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/915.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/915.png"
                    },
                    {
                        "id":  916,
                        "name":  "Fragroin",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/916.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/916.png"
                    },
                    {
                        "id":  917,
                        "name":  "Tissenboule",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/917.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/917.png"
                    },
                    {
                        "id":  918,
                        "name":  "Filentrappe",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/918.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/918.png"
                    },
                    {
                        "id":  919,
                        "name":  "Lilliterelle",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/919.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/919.png"
                    },
                    {
                        "id":  920,
                        "name":  "Gambex",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/920.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/920.png"
                    },
                    {
                        "id":  921,
                        "name":  "Pohm",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/921.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/921.png"
                    },
                    {
                        "id":  922,
                        "name":  "Pohmotte",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/922.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/922.png"
                    },
                    {
                        "id":  923,
                        "name":  "Pohmarmotte",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/923.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/923.png"
                    },
                    {
                        "id":  924,
                        "name":  "Compagnol",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/924.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/924.png"
                    },
                    {
                        "id":  925,
                        "name":  "Famignol",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/925.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/925.png"
                    },
                    {
                        "id":  926,
                        "name":  "Pâtachiot",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/926.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/926.png"
                    },
                    {
                        "id":  927,
                        "name":  "Briochien",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/927.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/927.png"
                    },
                    {
                        "id":  928,
                        "name":  "Olivini",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/928.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/928.png"
                    },
                    {
                        "id":  929,
                        "name":  "Olivado",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/929.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/929.png"
                    },
                    {
                        "id":  930,
                        "name":  "Arboliva",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/930.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/930.png"
                    },
                    {
                        "id":  931,
                        "name":  "Tapatoès",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/931.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/931.png"
                    },
                    {
                        "id":  932,
                        "name":  "Selutin",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/932.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/932.png"
                    },
                    {
                        "id":  933,
                        "name":  "Amassel",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/933.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/933.png"
                    },
                    {
                        "id":  934,
                        "name":  "Gigansel",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/934.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/934.png"
                    },
                    {
                        "id":  935,
                        "name":  "Charbambin",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/935.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/935.png"
                    },
                    {
                        "id":  936,
                        "name":  "Carmadura",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/936.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/936.png"
                    },
                    {
                        "id":  937,
                        "name":  "Malvalame",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/937.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/937.png"
                    },
                    {
                        "id":  938,
                        "name":  "Têtampoule",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/938.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/938.png"
                    },
                    {
                        "id":  939,
                        "name":  "Ampibidou",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/939.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/939.png"
                    },
                    {
                        "id":  940,
                        "name":  "Zapétrel",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/940.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/940.png"
                    },
                    {
                        "id":  941,
                        "name":  "Fulgulairo",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/941.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/941.png"
                    },
                    {
                        "id":  942,
                        "name":  "Grondogue",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/942.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/942.png"
                    },
                    {
                        "id":  943,
                        "name":  "Dogrino",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/943.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/943.png"
                    },
                    {
                        "id":  944,
                        "name":  "Gribouraigne",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/944.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/944.png"
                    },
                    {
                        "id":  945,
                        "name":  "Tag-Tag",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/945.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/945.png"
                    },
                    {
                        "id":  946,
                        "name":  "Virovent",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/946.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/946.png"
                    },
                    {
                        "id":  947,
                        "name":  "Virevorreur",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/947.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/947.png"
                    },
                    {
                        "id":  948,
                        "name":  "Terracool",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/948.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/948.png"
                    },
                    {
                        "id":  949,
                        "name":  "Terracruel",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/949.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/949.png"
                    },
                    {
                        "id":  950,
                        "name":  "Craparoi",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/950.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/950.png"
                    },
                    {
                        "id":  951,
                        "name":  "Pimito",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/951.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/951.png"
                    },
                    {
                        "id":  952,
                        "name":  "Scovilain",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/952.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/952.png"
                    },
                    {
                        "id":  953,
                        "name":  "Léboulérou",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/953.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/953.png"
                    },
                    {
                        "id":  954,
                        "name":  "Bérasca",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/954.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/954.png"
                    },
                    {
                        "id":  955,
                        "name":  "Flotillon",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/955.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/955.png"
                    },
                    {
                        "id":  956,
                        "name":  "Cléopsytra",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/956.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/956.png"
                    },
                    {
                        "id":  957,
                        "name":  "Forgerette",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/957.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/957.png"
                    },
                    {
                        "id":  958,
                        "name":  "Forgella",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/958.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/958.png"
                    },
                    {
                        "id":  959,
                        "name":  "Forgelina",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/959.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/959.png"
                    },
                    {
                        "id":  960,
                        "name":  "Taupikeau",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/960.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/960.png"
                    },
                    {
                        "id":  961,
                        "name":  "Triopikeau",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/961.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/961.png"
                    },
                    {
                        "id":  962,
                        "name":  "Lestombaile",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/962.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/962.png"
                    },
                    {
                        "id":  963,
                        "name":  "Dofin",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/963.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/963.png"
                    },
                    {
                        "id":  964,
                        "name":  "Superdofin",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/964.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/964.png"
                    },
                    {
                        "id":  965,
                        "name":  "Vrombi",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/965.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/965.png"
                    },
                    {
                        "id":  966,
                        "name":  "Vrombotor",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/966.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/966.png"
                    },
                    {
                        "id":  967,
                        "name":  "Motorizard",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/967.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/967.png"
                    },
                    {
                        "id":  968,
                        "name":  "Ferdeter",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/968.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/968.png"
                    },
                    {
                        "id":  969,
                        "name":  "Germéclat",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/969.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/969.png"
                    },
                    {
                        "id":  970,
                        "name":  "Floréclat",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/970.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/970.png"
                    },
                    {
                        "id":  971,
                        "name":  "Toutombe",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/971.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/971.png"
                    },
                    {
                        "id":  972,
                        "name":  "Tomberro",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/972.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/972.png"
                    },
                    {
                        "id":  973,
                        "name":  "Flamenroule",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/973.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/973.png"
                    },
                    {
                        "id":  974,
                        "name":  "Piétacé",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/974.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/974.png"
                    },
                    {
                        "id":  975,
                        "name":  "Balbalèze",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/975.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/975.png"
                    },
                    {
                        "id":  976,
                        "name":  "Délestin",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/976.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/976.png"
                    },
                    {
                        "id":  977,
                        "name":  "Oyacata",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/977.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/977.png"
                    },
                    {
                        "id":  978,
                        "name":  "Nigirigon",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/978.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/978.png"
                    },
                    {
                        "id":  979,
                        "name":  "Courrousinge",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/979.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/979.png"
                    },
                    {
                        "id":  980,
                        "name":  "Terraiste",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/980.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/980.png"
                    },
                    {
                        "id":  981,
                        "name":  "Farigiraf",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/981.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/981.png"
                    },
                    {
                        "id":  982,
                        "name":  "Deusolourdo",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/982.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/982.png"
                    },
                    {
                        "id":  983,
                        "name":  "Scalpereur",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/983.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/983.png"
                    },
                    {
                        "id":  984,
                        "name":  "Fort-Ivoire",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/984.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/984.png"
                    },
                    {
                        "id":  985,
                        "name":  "Hurle-Queue",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/985.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/985.png"
                    },
                    {
                        "id":  986,
                        "name":  "Fongus-Furie",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/986.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/986.png"
                    },
                    {
                        "id":  987,
                        "name":  "Flotte-Mèche",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/987.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/987.png"
                    },
                    {
                        "id":  988,
                        "name":  "Rampe-Ailes",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/988.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/988.png"
                    },
                    {
                        "id":  989,
                        "name":  "Pelage-Sablé",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/989.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/989.png"
                    },
                    {
                        "id":  990,
                        "name":  "Roue-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/990.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/990.png"
                    },
                    {
                        "id":  991,
                        "name":  "Hotte-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/991.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/991.png"
                    },
                    {
                        "id":  992,
                        "name":  "Paume-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/992.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/992.png"
                    },
                    {
                        "id":  993,
                        "name":  "Têtes-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/993.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/993.png"
                    },
                    {
                        "id":  994,
                        "name":  "Mite-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/994.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/994.png"
                    },
                    {
                        "id":  995,
                        "name":  "Épine-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/995.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/995.png"
                    },
                    {
                        "id":  996,
                        "name":  "Frigodo",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/996.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/996.png"
                    },
                    {
                        "id":  997,
                        "name":  "Cryodo",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/997.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/997.png"
                    },
                    {
                        "id":  998,
                        "name":  "Glaivodo",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/998.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/998.png"
                    },
                    {
                        "id":  999,
                        "name":  "Mordudor",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/999.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/999.png"
                    },
                    {
                        "id":  1000,
                        "name":  "Gromago",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1000.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1000.png"
                    },
                    {
                        "id":  1001,
                        "name":  "Chongjian",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1001.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1001.png"
                    },
                    {
                        "id":  1002,
                        "name":  "Baojian",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1002.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1002.png"
                    },
                    {
                        "id":  1003,
                        "name":  "Dinglu",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1003.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1003.png"
                    },
                    {
                        "id":  1004,
                        "name":  "Yuyu",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1004.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1004.png"
                    },
                    {
                        "id":  1005,
                        "name":  "Rugit-Lune",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1005.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1005.png"
                    },
                    {
                        "id":  1006,
                        "name":  "Garde-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1006.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1006.png"
                    },
                    {
                        "id":  1007,
                        "name":  "Koraidon",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1007.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1007.png"
                    },
                    {
                        "id":  1008,
                        "name":  "Miraidon",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1008.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1008.png"
                    },
                    {
                        "id":  1009,
                        "name":  "Serpente-Eau",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1009.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1009.png"
                    },
                    {
                        "id":  1010,
                        "name":  "Vert-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1010.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1010.png"
                    },
                    {
                        "id":  1011,
                        "name":  "Pomdramour",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1011.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1011.png"
                    },
                    {
                        "id":  1012,
                        "name":  "Poltchageist",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1012.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1012.png"
                    },
                    {
                        "id":  1013,
                        "name":  "Théffroyable",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1013.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1013.png"
                    },
                    {
                        "id":  1014,
                        "name":  "Félicanis",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1014.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1014.png"
                    },
                    {
                        "id":  1015,
                        "name":  "Fortusimia",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1015.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1015.png"
                    },
                    {
                        "id":  1016,
                        "name":  "Favianos",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1016.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1016.png"
                    },
                    {
                        "id":  1017,
                        "name":  "Ogerpon",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1017.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1017.png"
                    },
                    {
                        "id":  1018,
                        "name":  "Pondralugon",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1018.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1018.png"
                    },
                    {
                        "id":  1019,
                        "name":  "Pomdorochi",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1019.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1019.png"
                    },
                    {
                        "id":  1020,
                        "name":  "Feu-Perçant",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1020.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1020.png"
                    },
                    {
                        "id":  1021,
                        "name":  "Ire-Foudre",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1021.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1021.png"
                    },
                    {
                        "id":  1022,
                        "name":  "Roc-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1022.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1022.png"
                    },
                    {
                        "id":  1023,
                        "name":  "Chef-de-Fer",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1023.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1023.png"
                    },
                    {
                        "id":  1024,
                        "name":  "Terapagos",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1024.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1024.png"
                    },
                    {
                        "id":  1025,
                        "name":  "Pêchaminus",
                        "region":  "Paldea",
                        "generation":  9,
                        "sprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1025.png",
                        "shinySprite":  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/1025.png"
                    }
                ]
}
;
