(function () {
  const data = window.POKEMON_BASE;
  const pokemon = data.pokemon;
  const regions = data.regions;
  let collection = window.DexStorage.loadCollection(pokemon);
  let activeRegion = "all";
  let activeFilter = "all";
  let activeView = "dex";
  let currentPokemon = null;

  const el = {
    sidebar: document.getElementById("sidebar"),
    menuButton: document.getElementById("menuButton"),
    regionList: document.getElementById("regionList"),
    search: document.getElementById("searchInput"),
    summary: document.getElementById("summaryStats"),
    grid: document.getElementById("pokemonGrid"),
    currentScope: document.getElementById("currentScope"),
    heroTitle: document.getElementById("heroTitle"),
    globalPercent: document.getElementById("globalPercent"),
    globalCount: document.getElementById("globalCount"),
    globalBar: document.getElementById("globalBar"),
    statusFilters: document.getElementById("statusFilters"),
    sortSelect: document.getElementById("sortSelect"),
    dexView: document.getElementById("dexView"),
    statsView: document.getElementById("statsView"),
    dexToolbar: document.getElementById("dexToolbar"),
    regionStats: document.getElementById("regionStats"),
    huntStats: document.getElementById("huntStats"),
    detailDrawer: document.getElementById("detailDrawer"),
    detailContent: document.getElementById("detailContent"),
    drawerBackdrop: document.getElementById("drawerBackdrop"),
    drawerClose: document.getElementById("drawerClose"),
    exportButton: document.getElementById("exportButton"),
    importButton: document.getElementById("importButton"),
    importFile: document.getElementById("importFile")
  };

  function number(id) {
    return "#" + String(id).padStart(4, "0");
  }

  function percent(part, total) {
    return total ? Math.round((part / total) * 100) : 0;
  }

  function getVisiblePokemon() {
    const term = el.search.value.trim().toLowerCase();
    const visible = pokemon.filter((p) => {
      const entry = collection[p.id];
      if (activeRegion !== "all" && p.region !== activeRegion) return false;
      if (activeFilter === "caught" && !entry.caught) return false;
      if (activeFilter === "missing" && entry.caught) return false;
      if (activeFilter === "perfect" && !entry.perfect) return false;
      if (!term) return true;
      return String(p.id).includes(term) || p.name.toLowerCase().includes(term) || p.region.toLowerCase().includes(term);
    });

    const sort = el.sortSelect.value;
    visible.sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name, "fr");
      if (sort === "recent") return String(collection[b.id].updatedAt).localeCompare(String(collection[a.id].updatedAt));
      if (sort === "encounters") return Number(collection[b.id].encounters) - Number(collection[a.id].encounters);
      return a.id - b.id;
    });
    return visible;
  }

  function renderRegions(stats) {
    const allActive = activeRegion === "all" ? " active" : "";
    const allButton = `
      <button class="region-btn${allActive}" type="button" data-region="all" style="--region-color:var(--gold)">
        <i class="region-dot"></i>
        <span><span class="region-name">Toutes</span><br><span class="region-meta">${stats.caught}/${stats.total}</span></span>
        <strong>${stats.percent}%</strong>
      </button>`;
    const buttons = stats.regionStats.map((region) => `
      <button class="region-btn${activeRegion === region.name ? " active" : ""}" type="button" data-region="${region.name}" style="--region-color:${region.color}">
        <i class="region-dot"></i>
        <span><span class="region-name">${region.name}</span><br><span class="region-meta">Gen ${region.gen} · ${region.caught}/${region.total}</span></span>
        <strong>${region.percent}%</strong>
      </button>`).join("");
    el.regionList.innerHTML = allButton + buttons;
  }

  function renderSummary(stats) {
    el.globalPercent.textContent = stats.percent + "%";
    el.globalCount.textContent = `${stats.caught} / ${stats.total} capturés`;
    el.globalBar.style.width = stats.percent + "%";
    el.summary.innerHTML = [
      ["Capturés", stats.caught],
      ["Manquants", stats.missing],
      ["Parfaits", stats.perfect],
      ["Rencontres", stats.encounters.toLocaleString("fr-FR")]
    ].map(([label, value]) => `<article class="stat-card"><span>${label}</span><strong>${value}</strong></article>`).join("");
  }

  function renderGrid() {
    const visible = getVisiblePokemon();
    const scope = activeRegion === "all" ? "Tous les Pokémon" : activeRegion;
    el.currentScope.textContent = `${scope} · ${visible.length} affichés`;
    el.heroTitle.textContent = activeView === "stats" ? "Vue d'ensemble de ta chasse." : "Ton Shiny Dex, sans friction.";
    if (!visible.length) {
      el.grid.innerHTML = `<div class="empty-state">Aucun Pokémon ne correspond aux filtres actuels.</div>`;
      return;
    }
    el.grid.innerHTML = visible.map((p) => {
      const entry = collection[p.id];
      return `
        <button class="pokemon-card${entry.caught ? " caught" : ""}${entry.perfect ? " perfect" : ""}" type="button" data-id="${p.id}">
          <img src="${entry.caught ? p.shinySprite : p.sprite}" alt="">
          <div class="pokemon-number">${number(p.id)}</div>
          <div class="pokemon-name">${p.name}</div>
          <div class="badge-line">
            <span class="badge">${p.region}</span>
            ${entry.caught ? `<span class="badge caught">Shiny</span>` : `<span class="badge">À chasser</span>`}
            ${entry.perfect ? `<span class="badge perfect">Parfait</span>` : ""}
          </div>
        </button>`;
    }).join("");
  }

  function renderStatsPanels(stats) {
    el.regionStats.innerHTML = stats.regionStats.map((region) => `
      <div class="region-stat">
        <strong>${region.name}</strong>
        <div class="meter"><i style="width:${region.percent}%; background:${region.color}"></i></div>
        <span>${region.caught}/${region.total}</span>
      </div>`).join("");

    const averageEncounters = stats.caught ? Math.round(stats.encounters / stats.caught) : 0;
    const averageEggs = stats.perfect ? Math.round(stats.eggs / Math.max(stats.perfect, 1)) : 0;
    el.huntStats.innerHTML = `
      <div class="hunt-list">
        <div class="hunt-item"><span>Total rencontres</span><strong>${stats.encounters.toLocaleString("fr-FR")}</strong></div>
        <div class="hunt-item"><span>Moyenne rencontres/capture</span><strong>${averageEncounters.toLocaleString("fr-FR")}</strong></div>
        <div class="hunt-item"><span>Oeufs parent parfait</span><strong>${stats.eggs.toLocaleString("fr-FR")}</strong></div>
        <div class="hunt-item"><span>Moyenne oeufs/parfait</span><strong>${averageEggs.toLocaleString("fr-FR")}</strong></div>
      </div>`;
  }

  function render() {
    const stats = window.DexStats.compute(pokemon, collection, regions);
    renderRegions(stats);
    renderSummary(stats);
    renderGrid();
    renderStatsPanels(stats);
  }

  function openDetail(id) {
    currentPokemon = pokemon.find((p) => p.id === Number(id));
    const entry = collection[currentPokemon.id];
    el.detailContent.innerHTML = `
      <div class="detail-hero">
        <img src="${entry.caught ? currentPokemon.shinySprite : currentPokemon.sprite}" alt="">
        <div>
          <div class="pokemon-number">${number(currentPokemon.id)} · ${currentPokemon.region}</div>
          <h2>${currentPokemon.name}</h2>
          <div class="badge-line">
            ${entry.caught ? `<span class="badge caught">Shiny capturé</span>` : `<span class="badge">Manquant</span>`}
            ${entry.perfect ? `<span class="badge perfect">Parent parfait</span>` : ""}
          </div>
        </div>
      </div>
      <form class="form-grid" id="detailForm">
        <label class="check-row">Capturé <input name="caught" type="checkbox" ${entry.caught ? "checked" : ""}></label>
        <label class="check-row">Parfait <input name="perfect" type="checkbox" ${entry.perfect ? "checked" : ""}></label>
        <label class="field"><span>Surnom</span><input name="nickname" value="${escapeHtml(entry.nickname)}"></label>
        <label class="field"><span>Nombre de rencontres</span><input name="encounters" type="number" min="0" value="${entry.encounters || ""}"></label>
        <label class="field"><span>Oeufs parent parfait</span><input name="eggs" type="number" min="0" value="${entry.eggs || ""}"></label>
        <label class="field"><span>Date de capture</span><input name="captureDate" type="date" value="${entry.captureDate}"></label>
        <label class="field"><span>Lien YouTube</span><input name="videoUrl" type="url" value="${escapeHtml(entry.videoUrl)}"></label>
        <label class="field"><span>Contexte</span><textarea name="notes">${escapeHtml(entry.notes)}</textarea></label>
        <button class="primary-action" type="submit">Enregistrer</button>
      </form>`;
    el.detailDrawer.classList.add("open");
    el.drawerBackdrop.classList.add("open");
    el.detailDrawer.setAttribute("aria-hidden", "false");
  }

  function closeDetail() {
    el.detailDrawer.classList.remove("open");
    el.drawerBackdrop.classList.remove("open");
    el.detailDrawer.setAttribute("aria-hidden", "true");
  }

  function saveDetail(event) {
    event.preventDefault();
    const form = new FormData(event.target);
    collection[currentPokemon.id] = window.DexStorage.normalizeEntry({
      caught: form.get("caught") === "on",
      perfect: form.get("perfect") === "on",
      nickname: form.get("nickname"),
      encounters: form.get("encounters"),
      eggs: form.get("eggs"),
      captureDate: form.get("captureDate"),
      videoUrl: form.get("videoUrl"),
      notes: form.get("notes"),
      updatedAt: new Date().toISOString()
    });
    window.DexStorage.saveCollection(collection);
    render();
    closeDetail();
  }

  function escapeHtml(value) {
    return String(value || "").replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    }[char]));
  }

  function exportFile() {
    const blob = new Blob([JSON.stringify(window.DexStorage.exportCollection(collection, pokemon), null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "shiny-living-dex-export.json";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function bindEvents() {
    el.regionList.addEventListener("click", (event) => {
      const button = event.target.closest("[data-region]");
      if (!button) return;
      activeRegion = button.dataset.region;
      el.sidebar.classList.remove("open");
      render();
    });
    el.statusFilters.addEventListener("click", (event) => {
      const button = event.target.closest("[data-filter]");
      if (!button) return;
      activeFilter = button.dataset.filter;
      el.statusFilters.querySelectorAll("button").forEach((item) => item.classList.toggle("active", item === button));
      render();
    });
    document.querySelectorAll("[data-view]").forEach((button) => {
      button.addEventListener("click", () => {
        activeView = button.dataset.view;
        document.querySelectorAll("[data-view]").forEach((item) => item.classList.toggle("active", item === button));
        el.dexView.classList.toggle("active", activeView === "dex");
        el.statsView.classList.toggle("active", activeView === "stats");
        el.dexToolbar.style.display = activeView === "dex" ? "" : "none";
        render();
      });
    });
    el.search.addEventListener("input", render);
    el.sortSelect.addEventListener("change", render);
    el.grid.addEventListener("click", (event) => {
      const card = event.target.closest("[data-id]");
      if (card) openDetail(card.dataset.id);
    });
    el.detailContent.addEventListener("submit", saveDetail);
    el.drawerClose.addEventListener("click", closeDetail);
    el.drawerBackdrop.addEventListener("click", closeDetail);
    el.menuButton.addEventListener("click", () => el.sidebar.classList.toggle("open"));
    el.exportButton.addEventListener("click", exportFile);
    el.importButton.addEventListener("click", () => el.importFile.click());
    el.importFile.addEventListener("change", () => {
      const file = el.importFile.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        collection = window.DexStorage.importCollection(reader.result, pokemon);
        render();
      };
      reader.readAsText(file);
    });
  }

  bindEvents();
  render();
})();
